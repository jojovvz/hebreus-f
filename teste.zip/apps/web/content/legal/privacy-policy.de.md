---
title: Datenschutzerklärung
---

Dies ist die Platzhalterseite für Ihre Datenschutzerklärung. Bearbeiten Sie die Datei `content/legal/privacy-policy.md`, um Ihren eigenen Inhalt hinzuzufügen.
