(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_[locale]_not-found_tsx_df43b6._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_[locale]_not-found_tsx_df43b6._.js",
  "chunks": [
    "static/chunks/app_[locale]_not-found_tsx_939544._.js"
  ],
  "source": "dynamic"
});
