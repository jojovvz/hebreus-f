(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/pages__error_5771e1._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/pages__error_5771e1._.js",
  "chunks": [
    "static/chunks/[root of the server]__d9dbd3._.js",
    "static/chunks/8f3eb_react-dom_8079ab._.js",
    "static/chunks/08b5e__pnpm_626364._.js",
    "static/chunks/[root of the server]__fe64c3._.js"
  ],
  "source": "entry"
});
