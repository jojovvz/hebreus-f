(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_[locale]_(marketing)_layout_tsx_df43b6._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_[locale]_(marketing)_layout_tsx_df43b6._.js",
  "chunks": [
    "static/chunks/[project]__16823b._.js",
    "static/chunks/08b5e__pnpm_472bcf._.js"
  ],
  "source": "dynamic"
});
