(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_[locale]_[___rest]_page_tsx_df43b6._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_[locale]_[___rest]_page_tsx_df43b6._.js",
  "chunks": [
    "static/chunks/[project]__56fd55._.js"
  ],
  "source": "dynamic"
});
