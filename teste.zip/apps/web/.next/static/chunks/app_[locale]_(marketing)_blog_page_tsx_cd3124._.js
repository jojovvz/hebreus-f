(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_[locale]_(marketing)_blog_page_tsx_cd3124._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_[locale]_(marketing)_blog_page_tsx_cd3124._.js",
  "chunks": [
    "static/chunks/b9f18_next_ba6f1e._.js",
    "static/chunks/[project]_apps_web_245b2d._.js"
  ],
  "source": "dynamic"
});
