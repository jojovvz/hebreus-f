__turbopack_load_page_chunks__("/_app", [
  "static/chunks/[root of the server]__8cae5c._.js",
  "static/chunks/8f3eb_react-dom_8079ab._.js",
  "static/chunks/08b5e__pnpm_626364._.js",
  "static/chunks/[root of the server]__06eb6c._.js",
  "static/chunks/pages__app_5771e1._.js",
  "static/chunks/pages__app_590b08._.js"
])
