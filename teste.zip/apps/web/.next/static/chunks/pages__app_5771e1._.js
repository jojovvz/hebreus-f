(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/pages__app_5771e1._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/pages__app_5771e1._.js",
  "chunks": [
    "static/chunks/[root of the server]__8cae5c._.js",
    "static/chunks/8f3eb_react-dom_8079ab._.js",
    "static/chunks/08b5e__pnpm_626364._.js",
    "static/chunks/[root of the server]__06eb6c._.js"
  ],
  "source": "entry"
});
