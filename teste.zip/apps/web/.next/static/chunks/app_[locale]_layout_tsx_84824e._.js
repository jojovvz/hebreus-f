(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_[locale]_layout_tsx_84824e._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_[locale]_layout_tsx_84824e._.js",
  "chunks": [
    "static/chunks/38e4d_@trpc_server_dist_738d79._.js",
    "static/chunks/3e042_@trpc_client_dist_3c0cdc._.js",
    "static/chunks/b68b1_@tanstack_query-core_build_modern_cd9a92._.js",
    "static/chunks/08b5e__pnpm_222621._.js",
    "static/chunks/[project]_apps_web_7942e3._.js",
    "static/chunks/[root of the server]__84dde5._.css"
  ],
  "source": "dynamic"
});
