(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/[project]_apps_web_c4c472._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/[project]_apps_web_c4c472._.js",
  "chunks": [
    "static/chunks/b9f18_next_dist_compiled_react-dom_29f8ca._.js",
    "static/chunks/b9f18_next_dist_compiled_d13e44._.js",
    "static/chunks/b9f18_next_dist_client_54c62f._.js",
    "static/chunks/b9f18_next_dist_e2c4bb._.js",
    "static/chunks/de9e7_@swc_helpers_cjs_6ab2e1._.js",
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_d97ed6._.js"
  ],
  "source": "entry"
});
