(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_[locale]_(marketing)_(home)_page_tsx_cd3124._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_[locale]_(marketing)_(home)_page_tsx_cd3124._.js",
  "chunks": [
    "static/chunks/[project]_apps_web_432fe4._.js",
    "static/chunks/b9f18_next_8d8e96._.js",
    "static/chunks/52d6d_framer-motion_dist_es_render_dc2554._.js",
    "static/chunks/52d6d_framer-motion_dist_es_animation_6a241c._.js",
    "static/chunks/52d6d_framer-motion_dist_es_projection_cf54f1._.js",
    "static/chunks/52d6d_framer-motion_dist_es_b78cec._.js",
    "static/chunks/cdd06_@radix-ui_react-icons_dist_react-icons_esm_f0ff92.js",
    "static/chunks/73cc2_@radix-ui_react-select_dist_index_mjs_f25c8a._.js",
    "static/chunks/08b5e__pnpm_dd81d1._.js"
  ],
  "source": "dynamic"
});
