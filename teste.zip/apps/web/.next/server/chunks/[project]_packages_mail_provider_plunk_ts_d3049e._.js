module.exports = {

"[project]/packages/mail/provider/plunk.ts [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "send": (()=>send)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$logs$2f$index$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/packages/logs/index.ts [app-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$logs$2f$lib$2f$logger$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/packages/logs/lib/logger.ts [app-route] (ecmascript)");
;
const send = async ({ to, subject, html, text })=>{
    const response = await fetch("https://api.useplunk.com/v1/send", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${process.env.PLUNK_API_KEY}`
        },
        body: JSON.stringify({
            to,
            subject,
            body: html,
            text
        })
    });
    if (!response.ok) {
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$logs$2f$lib$2f$logger$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["logger"].error(await response.json());
        throw new Error("Could not send email");
    }
};
}}),

};

//# sourceMappingURL=%5Bproject%5D_packages_mail_provider_plunk_ts_d3049e._.js.map