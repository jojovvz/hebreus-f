module.exports = {

"[project]/apps/web/modules/marketing/blog/components/PostListItem.tsx (client proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "PostListItem": (()=>PostListItem)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-20241020__react@19.0.0-rc-65a56d0e-20241020/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const PostListItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call PostListItem() from the server but PostListItem is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/apps/web/modules/marketing/blog/components/PostListItem.tsx <module evaluation>", "PostListItem");
}}),
"[project]/apps/web/modules/marketing/blog/components/PostListItem.tsx (client proxy)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "PostListItem": (()=>PostListItem)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-20241020__react@19.0.0-rc-65a56d0e-20241020/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const PostListItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call PostListItem() from the server but PostListItem is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/apps/web/modules/marketing/blog/components/PostListItem.tsx", "PostListItem");
}}),
"[project]/apps/web/modules/marketing/blog/components/PostListItem.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: require } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$modules$2f$marketing$2f$blog$2f$components$2f$PostListItem$2e$tsx__$28$client__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/apps/web/modules/marketing/blog/components/PostListItem.tsx (client proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$modules$2f$marketing$2f$blog$2f$components$2f$PostListItem$2e$tsx__$28$client__proxy$29$__ = __turbopack_import__("[project]/apps/web/modules/marketing/blog/components/PostListItem.tsx (client proxy)");
;
__turbopack_export_namespace__(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$modules$2f$marketing$2f$blog$2f$components$2f$PostListItem$2e$tsx__$28$client__proxy$29$__);
}}),
"[project]/apps/web/.content-collections/generated/allPosts.js [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
const __TURBOPACK__default__export__ = [
    {
        "content": "## Meine Lieblingsdinge\n\nDas ist ein Testpost. Hier schreibe ich über meine Lieblingsdinge.",
        "title": "Lieblingsdinge",
        "date": "2023-02-28",
        "image": "/images/blog/cover.png",
        "authorName": "Elon Musk",
        "authorImage": "/images/blog/author2.jpg",
        "excerpt": "Hier schreibe ich über meine Lieblingsdinge.",
        "tags": [
            "first",
            "post"
        ],
        "published": true,
        "_meta": {
            "filePath": "first-post.de.mdx",
            "fileName": "first-post.de.mdx",
            "directory": ".",
            "extension": "mdx",
            "path": "first-post.de"
        },
        "body": "var Component=(()=>{var x=Object.create;var r=Object.defineProperty;var l=Object.getOwnPropertyDescriptor;var u=Object.getOwnPropertyNames;var _=Object.getPrototypeOf,g=Object.prototype.hasOwnProperty;var p=(e,n)=>()=>(n||e((n={exports:{}}).exports,n),n.exports),j=(e,n)=>{for(var i in n)r(e,i,{get:n[i],enumerable:!0})},c=(e,n,i,o)=>{if(n&&typeof n==\"object\"||typeof n==\"function\")for(let s of u(n))!g.call(e,s)&&s!==i&&r(e,s,{get:()=>n[s],enumerable:!(o=l(n,s))||o.enumerable});return e};var b=(e,n,i)=>(i=e!=null?x(_(e)):{},c(n||!e||!e.__esModule?r(i,\"default\",{value:e,enumerable:!0}):i,e)),f=e=>c(r({},\"__esModule\",{value:!0}),e);var h=p((L,a)=>{a.exports=_jsx_runtime});var M={};j(M,{default:()=>d});var t=b(h());function m(e){let n={h2:\"h2\",p:\"p\",...e.components};return(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(n.h2,{children:\"Meine Lieblingsdinge\"}),`\n`,(0,t.jsx)(n.p,{children:\"Das ist ein Testpost. Hier schreibe ich \\xFCber meine Lieblingsdinge.\"})]})}function d(e={}){let{wrapper:n}=e.components||{};return n?(0,t.jsx)(n,{...e,children:(0,t.jsx)(m,{...e})}):m(e)}return f(M);})();\n;return Component;",
        "locale": "de",
        "path": "first-post"
    },
    {
        "content": "## This is a heading\n\nAnd we also have some great content here. What do you think?",
        "title": "Favorite Things",
        "date": "2023-02-28",
        "image": "/images/blog/cover.png",
        "authorName": "Elon Musk",
        "authorImage": "/images/blog/author2.jpg",
        "excerpt": "In this post I'm going to tell you about my favorite things.",
        "tags": [
            "first",
            "post"
        ],
        "published": true,
        "_meta": {
            "filePath": "first-post.mdx",
            "fileName": "first-post.mdx",
            "directory": ".",
            "extension": "mdx",
            "path": "first-post"
        },
        "body": "var Component=(()=>{var u=Object.create;var s=Object.defineProperty;var x=Object.getOwnPropertyDescriptor;var _=Object.getOwnPropertyNames;var l=Object.getPrototypeOf,j=Object.prototype.hasOwnProperty;var p=(n,e)=>()=>(e||n((e={exports:{}}).exports,e),e.exports),f=(n,e)=>{for(var o in e)s(n,o,{get:e[o],enumerable:!0})},c=(n,e,o,a)=>{if(e&&typeof e==\"object\"||typeof e==\"function\")for(let r of _(e))!j.call(n,r)&&r!==o&&s(n,r,{get:()=>e[r],enumerable:!(a=x(e,r))||a.enumerable});return n};var g=(n,e,o)=>(o=n!=null?u(l(n)):{},c(e||!n||!n.__esModule?s(o,\"default\",{value:n,enumerable:!0}):o,n)),M=n=>c(s({},\"__esModule\",{value:!0}),n);var i=p((C,h)=>{h.exports=_jsx_runtime});var w={};f(w,{default:()=>m});var t=g(i());function d(n){let e={h2:\"h2\",p:\"p\",...n.components};return(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(e.h2,{children:\"This is a heading\"}),`\n`,(0,t.jsx)(e.p,{children:\"And we also have some great content here. What do you think?\"})]})}function m(n={}){let{wrapper:e}=n.components||{};return e?(0,t.jsx)(e,{...n,children:(0,t.jsx)(d,{...n})}):d(n)}return M(w);})();\n;return Component;",
        "locale": "en",
        "path": "first-post"
    },
    {
        "content": "## Hello world\n\nThis is my first post. I'm so excited! This blog posts needs some more text lines to fill up the page, so I'm just going to write some random stuff here. I'm going to write about my favorite things, like:\n\n### What's next?\n\nI'm going to write a lot more posts. I'm going to write about my favorite things, like:\n\n- Cats\n- Dogs\n- Pizza\n\nYou can even add some nice links here:\n\n- [My favorite cat](https://www.youtube.com/watch?v=5dsGWM5XGdg)\n- [My favorite dog](https://www.youtube.com/watch?v=5dsGWM5XGdg)\n- [My favorite pizza](https://www.youtube.com/watch?v=5dsGWM5XGdg)\n- [Homepage](/)",
        "title": "Awesome second post",
        "date": "2023-03-01",
        "image": "/images/blog/cover.png",
        "authorName": "Tony Stark",
        "authorImage": "/images/blog/author.jpg",
        "excerpt": "This is my first post. I'm so excited!",
        "tags": [
            "first",
            "post"
        ],
        "published": true,
        "_meta": {
            "filePath": "second-post.mdx",
            "fileName": "second-post.mdx",
            "directory": ".",
            "extension": "mdx",
            "path": "second-post"
        },
        "body": "var Component=(()=>{var m=Object.create;var r=Object.defineProperty;var u=Object.getOwnPropertyDescriptor;var g=Object.getOwnPropertyNames;var w=Object.getPrototypeOf,f=Object.prototype.hasOwnProperty;var p=(t,e)=>()=>(e||t((e={exports:{}}).exports,e),e.exports),x=(t,e)=>{for(var i in e)r(t,i,{get:e[i],enumerable:!0})},h=(t,e,i,l)=>{if(e&&typeof e==\"object\"||typeof e==\"function\")for(let o of g(e))!f.call(t,o)&&o!==i&&r(t,o,{get:()=>e[o],enumerable:!(l=u(e,o))||l.enumerable});return t};var y=(t,e,i)=>(i=t!=null?m(w(t)):{},h(e||!t||!t.__esModule?r(i,\"default\",{value:t,enumerable:!0}):i,t)),v=t=>h(r({},\"__esModule\",{value:!0}),t);var c=p((b,s)=>{s.exports=_jsx_runtime});var M={};x(M,{default:()=>d});var n=y(c());function a(t){let e={a:\"a\",h2:\"h2\",h3:\"h3\",li:\"li\",p:\"p\",ul:\"ul\",...t.components};return(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(e.h2,{children:\"Hello world\"}),`\n`,(0,n.jsx)(e.p,{children:\"This is my first post. I'm so excited! This blog posts needs some more text lines to fill up the page, so I'm just going to write some random stuff here. I'm going to write about my favorite things, like:\"}),`\n`,(0,n.jsx)(e.h3,{children:\"What's next?\"}),`\n`,(0,n.jsx)(e.p,{children:\"I'm going to write a lot more posts. I'm going to write about my favorite things, like:\"}),`\n`,(0,n.jsxs)(e.ul,{children:[`\n`,(0,n.jsx)(e.li,{children:\"Cats\"}),`\n`,(0,n.jsx)(e.li,{children:\"Dogs\"}),`\n`,(0,n.jsx)(e.li,{children:\"Pizza\"}),`\n`]}),`\n`,(0,n.jsx)(e.p,{children:\"You can even add some nice links here:\"}),`\n`,(0,n.jsxs)(e.ul,{children:[`\n`,(0,n.jsx)(e.li,{children:(0,n.jsx)(e.a,{href:\"https://www.youtube.com/watch?v=5dsGWM5XGdg\",children:\"My favorite cat\"})}),`\n`,(0,n.jsx)(e.li,{children:(0,n.jsx)(e.a,{href:\"https://www.youtube.com/watch?v=5dsGWM5XGdg\",children:\"My favorite dog\"})}),`\n`,(0,n.jsx)(e.li,{children:(0,n.jsx)(e.a,{href:\"https://www.youtube.com/watch?v=5dsGWM5XGdg\",children:\"My favorite pizza\"})}),`\n`,(0,n.jsx)(e.li,{children:(0,n.jsx)(e.a,{href:\"/\",children:\"Homepage\"})}),`\n`]})]})}function d(t={}){let{wrapper:e}=t.components||{};return e?(0,n.jsx)(e,{...t,children:(0,n.jsx)(a,{...t})}):a(t)}return v(M);})();\n;return Component;",
        "locale": "en",
        "path": "second-post"
    }
];
}}),
"[project]/apps/web/.content-collections/generated/allLegalPages.js [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
const __TURBOPACK__default__export__ = [
    {
        "content": "Dies ist die Platzhalterseite für Ihre Datenschutzerklärung. Bearbeiten Sie die Datei `content/legal/privacy-policy.md`, um Ihren eigenen Inhalt hinzuzufügen.",
        "title": "Datenschutzerklärung",
        "_meta": {
            "filePath": "privacy-policy.de.md",
            "fileName": "privacy-policy.de.md",
            "directory": ".",
            "extension": "md",
            "path": "privacy-policy.de"
        },
        "body": "var Component=(()=>{var h=Object.create;var o=Object.defineProperty;var m=Object.getOwnPropertyDescriptor;var x=Object.getOwnPropertyNames;var p=Object.getPrototypeOf,f=Object.prototype.hasOwnProperty;var _=(e,n)=>()=>(n||e((n={exports:{}}).exports,n),n.exports),j=(e,n)=>{for(var t in n)o(e,t,{get:n[t],enumerable:!0})},s=(e,n,t,c)=>{if(n&&typeof n==\"object\"||typeof n==\"function\")for(let i of x(n))!f.call(e,i)&&i!==t&&o(e,i,{get:()=>n[i],enumerable:!(c=m(n,i))||c.enumerable});return e};var D=(e,n,t)=>(t=e!=null?h(p(e)):{},s(n||!e||!e.__esModule?o(t,\"default\",{value:e,enumerable:!0}):t,e)),g=e=>s(o({},\"__esModule\",{value:!0}),e);var u=_((I,a)=>{a.exports=_jsx_runtime});var z={};j(z,{default:()=>l});var r=D(u());function d(e){let n={code:\"code\",p:\"p\",...e.components};return(0,r.jsxs)(n.p,{children:[\"Dies ist die Platzhalterseite f\\xFCr Ihre Datenschutzerkl\\xE4rung. Bearbeiten Sie die Datei \",(0,r.jsx)(n.code,{children:\"content/legal/privacy-policy.md\"}),\", um Ihren eigenen Inhalt hinzuzuf\\xFCgen.\"]})}function l(e={}){let{wrapper:n}=e.components||{};return n?(0,r.jsx)(n,{...e,children:(0,r.jsx)(d,{...e})}):d(e)}return g(z);})();\n;return Component;",
        "locale": "de",
        "path": "privacy-policy"
    },
    {
        "content": "This is the placeholder page for your privacy policy. Edit the `content/legal/privacy-policy.md` file to add your own content here.",
        "title": "Privacy Policy",
        "_meta": {
            "filePath": "privacy-policy.md",
            "fileName": "privacy-policy.md",
            "directory": ".",
            "extension": "md",
            "path": "privacy-policy"
        },
        "body": "var Component=(()=>{var u=Object.create;var r=Object.defineProperty;var h=Object.getOwnPropertyDescriptor;var x=Object.getOwnPropertyNames;var m=Object.getPrototypeOf,y=Object.prototype.hasOwnProperty;var f=(e,t)=>()=>(t||e((t={exports:{}}).exports,t),t.exports),_=(e,t)=>{for(var n in t)r(e,n,{get:t[n],enumerable:!0})},s=(e,t,n,i)=>{if(t&&typeof t==\"object\"||typeof t==\"function\")for(let c of x(t))!y.call(e,c)&&c!==n&&r(e,c,{get:()=>t[c],enumerable:!(i=h(t,c))||i.enumerable});return e};var j=(e,t,n)=>(n=e!=null?u(m(e)):{},s(t||!e||!e.__esModule?r(n,\"default\",{value:e,enumerable:!0}):n,e)),M=e=>s(r({},\"__esModule\",{value:!0}),e);var a=f((w,d)=>{d.exports=_jsx_runtime});var g={};_(g,{default:()=>p});var o=j(a());function l(e){let t={code:\"code\",p:\"p\",...e.components};return(0,o.jsxs)(t.p,{children:[\"This is the placeholder page for your privacy policy. Edit the \",(0,o.jsx)(t.code,{children:\"content/legal/privacy-policy.md\"}),\" file to add your own content here.\"]})}function p(e={}){let{wrapper:t}=e.components||{};return t?(0,o.jsx)(t,{...e,children:(0,o.jsx)(l,{...e})}):l(e)}return M(g);})();\n;return Component;",
        "locale": "en",
        "path": "privacy-policy"
    },
    {
        "content": "Dies ist die Platzhalterseite für Ihre Allgemeinen Geschäftsbedingungen. Bearbeiten Sie die Datei `content/legal/terms.de.md`, um Ihren eigenen Inhalt hinzuzufügen.",
        "title": "Allgemeine Geschäftsbedingungen",
        "_meta": {
            "filePath": "terms.de.md",
            "fileName": "terms.de.md",
            "directory": ".",
            "extension": "md",
            "path": "terms.de"
        },
        "body": "var Component=(()=>{var m=Object.create;var r=Object.defineProperty;var h=Object.getOwnPropertyDescriptor;var x=Object.getOwnPropertyNames;var f=Object.getPrototypeOf,g=Object.prototype.hasOwnProperty;var _=(e,n)=>()=>(n||e((n={exports:{}}).exports,n),n.exports),j=(e,n)=>{for(var t in n)r(e,t,{get:n[t],enumerable:!0})},c=(e,n,t,s)=>{if(n&&typeof n==\"object\"||typeof n==\"function\")for(let o of x(n))!g.call(e,o)&&o!==t&&r(e,o,{get:()=>n[o],enumerable:!(s=h(n,o))||s.enumerable});return e};var p=(e,n,t)=>(t=e!=null?m(f(e)):{},c(n||!e||!e.__esModule?r(t,\"default\",{value:e,enumerable:!0}):t,e)),D=e=>c(r({},\"__esModule\",{value:!0}),e);var a=_((M,d)=>{d.exports=_jsx_runtime});var z={};j(z,{default:()=>u});var i=p(a());function l(e){let n={code:\"code\",p:\"p\",...e.components};return(0,i.jsxs)(n.p,{children:[\"Dies ist die Platzhalterseite f\\xFCr Ihre Allgemeinen Gesch\\xE4ftsbedingungen. Bearbeiten Sie die Datei \",(0,i.jsx)(n.code,{children:\"content/legal/terms.de.md\"}),\", um Ihren eigenen Inhalt hinzuzuf\\xFCgen.\"]})}function u(e={}){let{wrapper:n}=e.components||{};return n?(0,i.jsx)(n,{...e,children:(0,i.jsx)(l,{...e})}):l(e)}return D(z);})();\n;return Component;",
        "locale": "de",
        "path": "terms"
    },
    {
        "content": "This is the placeholder page for your terms and conditions. Edit the `content/legal/terms.md` file to add your own content here.",
        "title": "Terms and conditions",
        "_meta": {
            "filePath": "terms.md",
            "fileName": "terms.md",
            "directory": ".",
            "extension": "md",
            "path": "terms"
        },
        "body": "var Component=(()=>{var u=Object.create;var c=Object.defineProperty;var h=Object.getOwnPropertyDescriptor;var x=Object.getOwnPropertyNames;var p=Object.getPrototypeOf,f=Object.prototype.hasOwnProperty;var _=(e,t)=>()=>(t||e((t={exports:{}}).exports,t),t.exports),j=(e,t)=>{for(var n in t)c(e,n,{get:t[n],enumerable:!0})},d=(e,t,n,s)=>{if(t&&typeof t==\"object\"||typeof t==\"function\")for(let r of x(t))!f.call(e,r)&&r!==n&&c(e,r,{get:()=>t[r],enumerable:!(s=h(t,r))||s.enumerable});return e};var y=(e,t,n)=>(n=e!=null?u(p(e)):{},d(t||!e||!e.__esModule?c(n,\"default\",{value:e,enumerable:!0}):n,e)),M=e=>d(c({},\"__esModule\",{value:!0}),e);var a=_((C,i)=>{i.exports=_jsx_runtime});var g={};j(g,{default:()=>m});var o=y(a());function l(e){let t={code:\"code\",p:\"p\",...e.components};return(0,o.jsxs)(t.p,{children:[\"This is the placeholder page for your terms and conditions. Edit the \",(0,o.jsx)(t.code,{children:\"content/legal/terms.md\"}),\" file to add your own content here.\"]})}function m(e={}){let{wrapper:t}=e.components||{};return t?(0,o.jsx)(t,{...e,children:(0,o.jsx)(l,{...e})}):l(e)}return M(g);})();\n;return Component;",
        "locale": "en",
        "path": "terms"
    }
];
}}),
"[project]/apps/web/.content-collections/generated/allDocumentationPages.js [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
const __TURBOPACK__default__export__ = [
    {
        "content": "Das hier ist die Übersichtseite.",
        "title": "Übersicht",
        "subtitle": "Das ist der erste Schritt",
        "_meta": {
            "filePath": "getting-started\\overview.de.md",
            "fileName": "overview.de.md",
            "directory": "getting-started",
            "extension": "md",
            "path": "getting-started\\overview.de"
        },
        "body": "var Component=(()=>{var d=Object.create;var r=Object.defineProperty;var p=Object.getOwnPropertyDescriptor;var _=Object.getOwnPropertyNames;var f=Object.getPrototypeOf,h=Object.prototype.hasOwnProperty;var j=(t,e)=>()=>(e||t((e={exports:{}}).exports,e),e.exports),l=(t,e)=>{for(var n in e)r(t,n,{get:e[n],enumerable:!0})},s=(t,e,n,i)=>{if(e&&typeof e==\"object\"||typeof e==\"function\")for(let o of _(e))!h.call(t,o)&&o!==n&&r(t,o,{get:()=>e[o],enumerable:!(i=p(e,o))||i.enumerable});return t};var D=(t,e,n)=>(n=t!=null?d(f(t)):{},s(e||!t||!t.__esModule?r(n,\"default\",{value:t,enumerable:!0}):n,t)),M=t=>s(r({},\"__esModule\",{value:!0}),t);var a=j((b,u)=>{u.exports=_jsx_runtime});var C={};l(C,{default:()=>x});var c=D(a());function m(t){let e={p:\"p\",...t.components};return(0,c.jsx)(e.p,{children:\"Das hier ist die \\xDCbersichtseite.\"})}function x(t={}){let{wrapper:e}=t.components||{};return e?(0,c.jsx)(e,{...t,children:(0,c.jsx)(m,{...t})}):m(t)}return M(C);})();\n;return Component;",
        "locale": "de",
        "path": "getting-started\\overview",
        "toc": []
    },
    {
        "content": "This is the overview page of the getting started section.\n\n![Login](/images/docs/login.png)",
        "title": "Overview",
        "subtitle": "This is the first step to start using acme",
        "_meta": {
            "filePath": "getting-started\\overview.md",
            "fileName": "overview.md",
            "directory": "getting-started",
            "extension": "md",
            "path": "getting-started\\overview"
        },
        "body": "var Component=(()=>{var d=Object.create;var s=Object.defineProperty;var p=Object.getOwnPropertyDescriptor;var x=Object.getOwnPropertyNames;var l=Object.getPrototypeOf,u=Object.prototype.hasOwnProperty;var _=(t,n)=>()=>(n||t((n={exports:{}}).exports,n),n.exports),f=(t,n)=>{for(var i in n)s(t,i,{get:n[i],enumerable:!0})},c=(t,n,i,r)=>{if(n&&typeof n==\"object\"||typeof n==\"function\")for(let o of x(n))!u.call(t,o)&&o!==i&&s(t,o,{get:()=>n[o],enumerable:!(r=p(n,o))||r.enumerable});return t};var j=(t,n,i)=>(i=t!=null?d(l(t)):{},c(n||!t||!t.__esModule?s(i,\"default\",{value:t,enumerable:!0}):i,t)),w=t=>c(s({},\"__esModule\",{value:!0}),t);var g=_((C,a)=>{a.exports=_jsx_runtime});var M={};f(M,{default:()=>h});var e=j(g());function m(t){let n={img:\"img\",p:\"p\",...t.components};return(0,e.jsxs)(e.Fragment,{children:[(0,e.jsx)(n.p,{children:\"This is the overview page of the getting started section.\"}),`\n`,(0,e.jsx)(n.p,{children:(0,e.jsx)(n.img,{src:\"/images/docs/login.png\",alt:\"Login\",width:\"2282\",height:\"1434\"})})]})}function h(t={}){let{wrapper:n}=t.components||{};return n?(0,e.jsx)(n,{...t,children:(0,e.jsx)(m,{...t})}):m(t)}return w(M);})();\n;return Component;",
        "locale": "en",
        "path": "getting-started\\overview",
        "toc": []
    },
    {
        "content": "Willkommen zur Dokumentation von acme. Hier finden Sie alle Informationen, die Sie benötigen, um mit unserer Software zu arbeiten.",
        "title": "Dokumentation",
        "_meta": {
            "filePath": "index.de.md",
            "fileName": "index.de.md",
            "directory": ".",
            "extension": "md",
            "path": "index.de"
        },
        "body": "var Component=(()=>{var l=Object.create;var r=Object.defineProperty;var d=Object.getOwnPropertyDescriptor;var x=Object.getOwnPropertyNames;var p=Object.getPrototypeOf,_=Object.prototype.hasOwnProperty;var j=(n,e)=>()=>(e||n((e={exports:{}}).exports,e),e.exports),D=(n,e)=>{for(var t in e)r(n,t,{get:e[t],enumerable:!0})},u=(n,e,t,m)=>{if(e&&typeof e==\"object\"||typeof e==\"function\")for(let o of x(e))!_.call(n,o)&&o!==t&&r(n,o,{get:()=>e[o],enumerable:!(m=d(e,o))||m.enumerable});return n};var M=(n,e,t)=>(t=n!=null?l(p(n)):{},u(e||!n||!n.__esModule?r(t,\"default\",{value:n,enumerable:!0}):t,n)),S=n=>u(r({},\"__esModule\",{value:!0}),n);var c=j((k,a)=>{a.exports=_jsx_runtime});var b={};D(b,{default:()=>f});var i=M(c());function s(n){let e={p:\"p\",...n.components};return(0,i.jsx)(e.p,{children:\"Willkommen zur Dokumentation von acme. Hier finden Sie alle Informationen, die Sie ben\\xF6tigen, um mit unserer Software zu arbeiten.\"})}function f(n={}){let{wrapper:e}=n.components||{};return e?(0,i.jsx)(e,{...n,children:(0,i.jsx)(s,{...n})}):s(n)}return S(b);})();\n;return Component;",
        "locale": "de",
        "path": "",
        "toc": []
    },
    {
        "content": "Welcome to the documentation of acme. Here you will find all the information you need to work with our software. \n\n\n## 1.1 Getting started - Overview\n\nLorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. \n\nDuis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. \n\n### Another sub-section\n\nLorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. \n\nDuis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. \n\n## Code example\n\nThis is an example of code highlighting:\n\n```python {1}\ndef hello_world():\n    print(\"Hello World!\")\n```\n\n## Images\n\nThis is an example of an image:\n\n![Login](/images/docs/login.png)\n\n## Lists\n\nThis is an example of a list:\n\n- Item 1\n- Item 2\n- Item 3",
        "title": "Documentation",
        "_meta": {
            "filePath": "index.md",
            "fileName": "index.md",
            "directory": ".",
            "extension": "md",
            "path": "index"
        },
        "body": "var Component=(()=>{var c=Object.create;var s=Object.defineProperty;var p=Object.getOwnPropertyDescriptor;var h=Object.getOwnPropertyNames;var g=Object.getPrototypeOf,v=Object.prototype.hasOwnProperty;var y=(i,e)=>()=>(e||i((e={exports:{}}).exports,e),e.exports),b=(i,e)=>{for(var o in e)s(i,o,{get:e[o],enumerable:!0})},r=(i,e,o,n)=>{if(e&&typeof e==\"object\"||typeof e==\"function\")for(let a of h(e))!v.call(i,a)&&a!==o&&s(i,a,{get:()=>e[a],enumerable:!(n=p(e,a))||n.enumerable});return i};var f=(i,e,o)=>(o=i!=null?c(g(i)):{},r(e||!i||!i.__esModule?s(o,\"default\",{value:i,enumerable:!0}):o,i)),L=i=>r(s({},\"__esModule\",{value:!0}),i);var d=y((C,l)=>{l.exports=_jsx_runtime});var k={};b(k,{default:()=>m});var t=f(d());function u(i){let e={code:\"code\",h2:\"h2\",h3:\"h3\",img:\"img\",li:\"li\",p:\"p\",pre:\"pre\",span:\"span\",ul:\"ul\",...i.components};return(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(e.p,{children:\"Welcome to the documentation of acme. Here you will find all the information you need to work with our software.\"}),`\n`,(0,t.jsx)(e.h2,{children:\"1.1 Getting started - Overview\"}),`\n`,(0,t.jsx)(e.p,{children:\"Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.\"}),`\n`,(0,t.jsx)(e.p,{children:\"Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.\"}),`\n`,(0,t.jsx)(e.h3,{children:\"Another sub-section\"}),`\n`,(0,t.jsx)(e.p,{children:\"Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.\"}),`\n`,(0,t.jsx)(e.p,{children:\"Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.\"}),`\n`,(0,t.jsx)(e.h2,{children:\"Code example\"}),`\n`,(0,t.jsx)(e.p,{children:\"This is an example of code highlighting:\"}),`\n`,(0,t.jsx)(e.pre,{className:\"shiki nord\",style:{backgroundColor:\"#2e3440ff\",color:\"#d8dee9ff\"},tabIndex:\"0\",children:(0,t.jsxs)(e.code,{children:[(0,t.jsxs)(e.span,{className:\"line\",children:[(0,t.jsx)(e.span,{style:{color:\"#81A1C1\"},children:\"def\"}),(0,t.jsx)(e.span,{style:{color:\"#88C0D0\"},children:\" hello_world\"}),(0,t.jsx)(e.span,{style:{color:\"#ECEFF4\"},children:\"():\"})]}),`\n`,(0,t.jsxs)(e.span,{className:\"line\",children:[(0,t.jsx)(e.span,{style:{color:\"#88C0D0\"},children:\"    print\"}),(0,t.jsx)(e.span,{style:{color:\"#ECEFF4\"},children:\"(\"}),(0,t.jsx)(e.span,{style:{color:\"#ECEFF4\"},children:'\"'}),(0,t.jsx)(e.span,{style:{color:\"#A3BE8C\"},children:\"Hello World!\"}),(0,t.jsx)(e.span,{style:{color:\"#ECEFF4\"},children:'\"'}),(0,t.jsx)(e.span,{style:{color:\"#ECEFF4\"},children:\")\"})]})]})}),`\n`,(0,t.jsx)(e.h2,{children:\"Images\"}),`\n`,(0,t.jsx)(e.p,{children:\"This is an example of an image:\"}),`\n`,(0,t.jsx)(e.p,{children:(0,t.jsx)(e.img,{src:\"/images/docs/login.png\",alt:\"Login\",width:\"2282\",height:\"1434\"})}),`\n`,(0,t.jsx)(e.h2,{children:\"Lists\"}),`\n`,(0,t.jsx)(e.p,{children:\"This is an example of a list:\"}),`\n`,(0,t.jsxs)(e.ul,{children:[`\n`,(0,t.jsx)(e.li,{children:\"Item 1\"}),`\n`,(0,t.jsx)(e.li,{children:\"Item 2\"}),`\n`,(0,t.jsx)(e.li,{children:\"Item 3\"}),`\n`]})]})}function m(i={}){let{wrapper:e}=i.components||{};return e?(0,t.jsx)(e,{...i,children:(0,t.jsx)(u,{...i})}):u(i)}return L(k);})();\n;return Component;",
        "locale": "en",
        "path": "",
        "toc": [
            {
                "content": "1.1 Getting started - Overview",
                "slug": "11-getting-started-overview",
                "lvl": 2,
                "i": 0,
                "seen": 0
            },
            {
                "content": "Another sub-section",
                "slug": "another-sub-section",
                "lvl": 3,
                "i": 1,
                "seen": 0
            },
            {
                "content": "Code example",
                "slug": "code-example",
                "lvl": 2,
                "i": 2,
                "seen": 0
            },
            {
                "content": "Images",
                "slug": "images",
                "lvl": 2,
                "i": 3,
                "seen": 0
            },
            {
                "content": "Lists",
                "slug": "lists",
                "lvl": 2,
                "i": 4,
                "seen": 0
            }
        ]
    },
    {
        "content": "asdf",
        "title": "Installation",
        "_meta": {
            "filePath": "installation\\index.md",
            "fileName": "index.md",
            "directory": "installation",
            "extension": "md",
            "path": "installation\\index"
        },
        "body": "var Component=(()=>{var d=Object.create;var r=Object.defineProperty;var f=Object.getOwnPropertyDescriptor;var p=Object.getOwnPropertyNames;var _=Object.getPrototypeOf,j=Object.prototype.hasOwnProperty;var l=(n,t)=>()=>(t||n((t={exports:{}}).exports,t),t.exports),M=(n,t)=>{for(var e in t)r(n,e,{get:t[e],enumerable:!0})},u=(n,t,e,s)=>{if(t&&typeof t==\"object\"||typeof t==\"function\")for(let o of p(t))!j.call(n,o)&&o!==e&&r(n,o,{get:()=>t[o],enumerable:!(s=f(t,o))||s.enumerable});return n};var h=(n,t,e)=>(e=n!=null?d(_(n)):{},u(t||!n||!n.__esModule?r(e,\"default\",{value:n,enumerable:!0}):e,n)),C=n=>u(r({},\"__esModule\",{value:!0}),n);var i=l((w,a)=>{a.exports=_jsx_runtime});var D={};M(D,{default:()=>x});var c=h(i());function m(n){let t={p:\"p\",...n.components};return(0,c.jsx)(t.p,{children:\"asdf\"})}function x(n={}){let{wrapper:t}=n.components||{};return t?(0,c.jsx)(t,{...n,children:(0,c.jsx)(m,{...n})}):m(n)}return C(D);})();\n;return Component;",
        "locale": "en",
        "path": "installation\\",
        "toc": []
    },
    {
        "content": "asdf",
        "title": "Installation on macos",
        "_meta": {
            "filePath": "installation\\macos.md",
            "fileName": "macos.md",
            "directory": "installation",
            "extension": "md",
            "path": "installation\\macos"
        },
        "body": "var Component=(()=>{var d=Object.create;var r=Object.defineProperty;var f=Object.getOwnPropertyDescriptor;var p=Object.getOwnPropertyNames;var _=Object.getPrototypeOf,j=Object.prototype.hasOwnProperty;var l=(n,t)=>()=>(t||n((t={exports:{}}).exports,t),t.exports),M=(n,t)=>{for(var e in t)r(n,e,{get:t[e],enumerable:!0})},u=(n,t,e,s)=>{if(t&&typeof t==\"object\"||typeof t==\"function\")for(let o of p(t))!j.call(n,o)&&o!==e&&r(n,o,{get:()=>t[o],enumerable:!(s=f(t,o))||s.enumerable});return n};var h=(n,t,e)=>(e=n!=null?d(_(n)):{},u(t||!n||!n.__esModule?r(e,\"default\",{value:n,enumerable:!0}):e,n)),C=n=>u(r({},\"__esModule\",{value:!0}),n);var i=l((w,a)=>{a.exports=_jsx_runtime});var D={};M(D,{default:()=>x});var c=h(i());function m(n){let t={p:\"p\",...n.components};return(0,c.jsx)(t.p,{children:\"asdf\"})}function x(n={}){let{wrapper:t}=n.components||{};return t?(0,c.jsx)(t,{...n,children:(0,c.jsx)(m,{...n})}):m(n)}return C(D);})();\n;return Component;",
        "locale": "en",
        "path": "installation\\macos",
        "toc": []
    },
    {
        "content": "This is the overview page of the getting started section.",
        "title": "Overview",
        "subtitle": "This is the first step to start using acme",
        "_meta": {
            "filePath": "installation\\overview.de.md",
            "fileName": "overview.de.md",
            "directory": "installation",
            "extension": "md",
            "path": "installation\\overview.de"
        },
        "body": "var Component=(()=>{var x=Object.create;var r=Object.defineProperty;var d=Object.getOwnPropertyDescriptor;var f=Object.getOwnPropertyNames;var h=Object.getPrototypeOf,_=Object.prototype.hasOwnProperty;var g=(t,e)=>()=>(e||t((e={exports:{}}).exports,e),e.exports),j=(t,e)=>{for(var n in e)r(t,n,{get:e[n],enumerable:!0})},s=(t,e,n,i)=>{if(e&&typeof e==\"object\"||typeof e==\"function\")for(let o of f(e))!_.call(t,o)&&o!==n&&r(t,o,{get:()=>e[o],enumerable:!(i=d(e,o))||i.enumerable});return t};var l=(t,e,n)=>(n=t!=null?x(h(t)):{},s(e||!t||!t.__esModule?r(n,\"default\",{value:t,enumerable:!0}):n,t)),M=t=>s(r({},\"__esModule\",{value:!0}),t);var u=g((C,a)=>{a.exports=_jsx_runtime});var v={};j(v,{default:()=>p});var c=l(u());function m(t){let e={p:\"p\",...t.components};return(0,c.jsx)(e.p,{children:\"This is the overview page of the getting started section.\"})}function p(t={}){let{wrapper:e}=t.components||{};return e?(0,c.jsx)(e,{...t,children:(0,c.jsx)(m,{...t})}):m(t)}return M(v);})();\n;return Component;",
        "locale": "de",
        "path": "installation\\overview",
        "toc": []
    },
    {
        "content": "This is the overview page of the getting started section.",
        "title": "Overview",
        "subtitle": "This is the first step to start using acme",
        "_meta": {
            "filePath": "installation\\overview.md",
            "fileName": "overview.md",
            "directory": "installation",
            "extension": "md",
            "path": "installation\\overview"
        },
        "body": "var Component=(()=>{var x=Object.create;var r=Object.defineProperty;var d=Object.getOwnPropertyDescriptor;var f=Object.getOwnPropertyNames;var h=Object.getPrototypeOf,_=Object.prototype.hasOwnProperty;var g=(t,e)=>()=>(e||t((e={exports:{}}).exports,e),e.exports),j=(t,e)=>{for(var n in e)r(t,n,{get:e[n],enumerable:!0})},s=(t,e,n,i)=>{if(e&&typeof e==\"object\"||typeof e==\"function\")for(let o of f(e))!_.call(t,o)&&o!==n&&r(t,o,{get:()=>e[o],enumerable:!(i=d(e,o))||i.enumerable});return t};var l=(t,e,n)=>(n=t!=null?x(h(t)):{},s(e||!t||!t.__esModule?r(n,\"default\",{value:t,enumerable:!0}):n,t)),M=t=>s(r({},\"__esModule\",{value:!0}),t);var u=g((C,a)=>{a.exports=_jsx_runtime});var v={};j(v,{default:()=>p});var c=l(u());function m(t){let e={p:\"p\",...t.components};return(0,c.jsx)(e.p,{children:\"This is the overview page of the getting started section.\"})}function p(t={}){let{wrapper:e}=t.components||{};return e?(0,c.jsx)(e,{...t,children:(0,c.jsx)(m,{...t})}):m(t)}return M(v);})();\n;return Component;",
        "locale": "en",
        "path": "installation\\overview",
        "toc": []
    }
];
}}),
"[project]/apps/web/.content-collections/generated/allDocumentationMetas.js [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
const __TURBOPACK__default__export__ = [
    {
        "data": {
            "overview": "Übersicht"
        },
        "path": "",
        "locale": "de"
    },
    {
        "data": {
            "overview": "Overview"
        },
        "path": "",
        "locale": "en"
    },
    {
        "data": {
            "overview": "Overview",
            "macos": "macOS"
        },
        "path": "",
        "locale": "en"
    },
    {
        "data": {
            "getting-started": "Getting Started",
            "installation": "Installation"
        },
        "path": "",
        "locale": "en"
    }
];
}}),
"[project]/apps/web/.content-collections/generated/index.js [app-rsc] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: require } = __turbopack_context__;
{
// generated by content-collections at Tue Dec 31 2024 14:35:58 GMT-0300 (Horário Padrão de Brasília)
__turbopack_esm__({});
;
;
;
;
;
}}),
"[project]/apps/web/.content-collections/generated/index.js [app-rsc] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, t: require } = __turbopack_context__;
{
__turbopack_esm__({});
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f2e$content$2d$collections$2f$generated$2f$allPosts$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/apps/web/.content-collections/generated/allPosts.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f2e$content$2d$collections$2f$generated$2f$allLegalPages$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/apps/web/.content-collections/generated/allLegalPages.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f2e$content$2d$collections$2f$generated$2f$allDocumentationPages$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/apps/web/.content-collections/generated/allDocumentationPages.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f2e$content$2d$collections$2f$generated$2f$allDocumentationMetas$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/apps/web/.content-collections/generated/allDocumentationMetas.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f2e$content$2d$collections$2f$generated$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/apps/web/.content-collections/generated/index.js [app-rsc] (ecmascript) <locals>");
}}),
"[project]/apps/web/.content-collections/generated/allPosts.js [app-rsc] (ecmascript) <export default as allPosts>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, t: require } = __turbopack_context__;
{
__turbopack_esm__({
    "allPosts": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f2e$content$2d$collections$2f$generated$2f$allPosts$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f2e$content$2d$collections$2f$generated$2f$allPosts$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/apps/web/.content-collections/generated/allPosts.js [app-rsc] (ecmascript)");
}}),
"[project]/apps/web/app/[locale]/(marketing)/blog/page.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>BlogListPage),
    "generateMetadata": (()=>generateMetadata)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-20241020__react@19.0.0-rc-65a56d0e-20241020/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$modules$2f$marketing$2f$blog$2f$components$2f$PostListItem$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/apps/web/modules/marketing/blog/components/PostListItem.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f2e$content$2d$collections$2f$generated$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/apps/web/.content-collections/generated/index.js [app-rsc] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$intl$40$3$2e$25$2e$1_next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$2_femrh4wds34izboa6tviasui5q$2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$server$2f$react$2d$server$2f$getLocale$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__getLocale$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/esm/server/react-server/getLocale.js [app-rsc] (ecmascript) <export default as getLocale>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$intl$40$3$2e$25$2e$1_next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$2_femrh4wds34izboa6tviasui5q$2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$server$2f$react$2d$server$2f$getTranslations$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__getTranslations$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/esm/server/react-server/getTranslations.js [app-rsc] (ecmascript) <export default as getTranslations>");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f2e$content$2d$collections$2f$generated$2f$allPosts$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__allPosts$3e$__ = __turbopack_import__("[project]/apps/web/.content-collections/generated/allPosts.js [app-rsc] (ecmascript) <export default as allPosts>");
;
;
;
;
async function generateMetadata() {
    const t = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$intl$40$3$2e$25$2e$1_next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$2_femrh4wds34izboa6tviasui5q$2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$server$2f$react$2d$server$2f$getTranslations$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__getTranslations$3e$__["getTranslations"])();
    return {
        title: t("blog.title")
    };
}
async function BlogListPage() {
    const locale = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$intl$40$3$2e$25$2e$1_next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$2_femrh4wds34izboa6tviasui5q$2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$server$2f$react$2d$server$2f$getLocale$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__getLocale$3e$__["getLocale"])();
    const t = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$intl$40$3$2e$25$2e$1_next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$2_femrh4wds34izboa6tviasui5q$2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$server$2f$react$2d$server$2f$getTranslations$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__getTranslations$3e$__["getTranslations"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "container max-w-6xl pt-32 pb-16",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-12 pt-8 text-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "mb-2 font-bold text-5xl",
                        children: t("blog.title")
                    }, void 0, false, {
                        fileName: "[project]/apps/web/app/[locale]/(marketing)/blog/page.tsx",
                        lineNumber: 19,
                        columnNumber: 5
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-lg opacity-50",
                        children: t("blog.description")
                    }, void 0, false, {
                        fileName: "[project]/apps/web/app/[locale]/(marketing)/blog/page.tsx",
                        lineNumber: 20,
                        columnNumber: 5
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/web/app/[locale]/(marketing)/blog/page.tsx",
                lineNumber: 18,
                columnNumber: 4
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid gap-8 md:grid-cols-2",
                children: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f2e$content$2d$collections$2f$generated$2f$allPosts$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__allPosts$3e$__["allPosts"].filter((post)=>post.published && locale === post.locale).sort((a, b)=>new Date(b.date).getTime() - new Date(a.date).getTime()).map((post)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$modules$2f$marketing$2f$blog$2f$components$2f$PostListItem$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["PostListItem"], {
                        post: post
                    }, post.path, false, {
                        fileName: "[project]/apps/web/app/[locale]/(marketing)/blog/page.tsx",
                        lineNumber: 30,
                        columnNumber: 7
                    }, this))
            }, void 0, false, {
                fileName: "[project]/apps/web/app/[locale]/(marketing)/blog/page.tsx",
                lineNumber: 23,
                columnNumber: 4
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/web/app/[locale]/(marketing)/blog/page.tsx",
        lineNumber: 17,
        columnNumber: 3
    }, this);
}
}}),
"[project]/apps/web/app/[locale]/(marketing)/blog/page.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: require } = __turbopack_context__;
{
__turbopack_export_namespace__(__turbopack_import__("[project]/apps/web/app/[locale]/(marketing)/blog/page.tsx [app-rsc] (ecmascript)"));
}}),
"[project]/apps/web/modules/shared/lib/cache.ts [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: require } = __turbopack_context__;
{
/* __next_internal_action_entry_do_not_use__ {"7ffca56d615d22c5c3942bacb3c6b36d4da5e7c394":"clearCache"} */ __turbopack_esm__({
    "clearCache": (()=>clearCache)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-20241020__react@19.0.0-rc-65a56d0e-20241020/node_modules/next/dist/build/webpack/loaders/next-flight-loader/server-reference.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$app$2d$render$2f$encryption$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-20241020__react@19.0.0-rc-65a56d0e-20241020/node_modules/next/dist/server/app-render/encryption.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$cache$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-20241020__react@19.0.0-rc-65a56d0e-20241020/node_modules/next/cache.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-20241020__react@19.0.0-rc-65a56d0e-20241020/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-validate.js [app-rsc] (ecmascript)");
;
;
;
const clearCache = async (path)=>{
    try {
        if (path) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$cache$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["revalidatePath"])(path);
        } else {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$cache$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["revalidatePath"])("/", "layout");
        }
    } catch (error) {
        console.error("Could not revalidate path", path, error);
    }
};
;
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ensureServerEntryExports"])([
    clearCache
]);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(clearCache, "7ffca56d615d22c5c3942bacb3c6b36d4da5e7c394", null);
}}),
"[project]/apps/web/.next-internal/server/app/[locale]/(marketing)/blog/page/actions.js { ACTIONS_MODULE0 => \"[project]/apps/web/modules/shared/lib/cache.ts [app-rsc] (ecmascript)\" } [app-rsc] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: require } = __turbopack_context__;
{
__turbopack_esm__({});
;
}}),
"[project]/apps/web/.next-internal/server/app/[locale]/(marketing)/blog/page/actions.js { ACTIONS_MODULE0 => \"[project]/apps/web/modules/shared/lib/cache.ts [app-rsc] (ecmascript)\" } [app-rsc] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, t: require } = __turbopack_context__;
{
__turbopack_esm__({});
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$modules$2f$shared$2f$lib$2f$cache$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/apps/web/modules/shared/lib/cache.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f2e$next$2d$internal$2f$server$2f$app$2f5b$locale$5d2f28$marketing$292f$blog$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$apps$2f$web$2f$modules$2f$shared$2f$lib$2f$cache$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__('[project]/apps/web/.next-internal/server/app/[locale]/(marketing)/blog/page/actions.js { ACTIONS_MODULE0 => "[project]/apps/web/modules/shared/lib/cache.ts [app-rsc] (ecmascript)" } [app-rsc] (ecmascript) <locals>');
}}),
"[project]/apps/web/.next-internal/server/app/[locale]/(marketing)/blog/page/actions.js { ACTIONS_MODULE0 => \"[project]/apps/web/modules/shared/lib/cache.ts [app-rsc] (ecmascript)\" } [app-rsc] (ecmascript) <exports>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, t: require } = __turbopack_context__;
{
__turbopack_esm__({
    "7ffca56d615d22c5c3942bacb3c6b36d4da5e7c394": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$modules$2f$shared$2f$lib$2f$cache$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["clearCache"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$modules$2f$shared$2f$lib$2f$cache$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/apps/web/modules/shared/lib/cache.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f2e$next$2d$internal$2f$server$2f$app$2f5b$locale$5d2f28$marketing$292f$blog$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$apps$2f$web$2f$modules$2f$shared$2f$lib$2f$cache$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__('[project]/apps/web/.next-internal/server/app/[locale]/(marketing)/blog/page/actions.js { ACTIONS_MODULE0 => "[project]/apps/web/modules/shared/lib/cache.ts [app-rsc] (ecmascript)" } [app-rsc] (ecmascript) <locals>');
}}),
"[project]/apps/web/.next-internal/server/app/[locale]/(marketing)/blog/page/actions.js { ACTIONS_MODULE0 => \"[project]/apps/web/modules/shared/lib/cache.ts [app-rsc] (ecmascript)\" } [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, t: require } = __turbopack_context__;
{
__turbopack_esm__({
    "7ffca56d615d22c5c3942bacb3c6b36d4da5e7c394": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f2e$next$2d$internal$2f$server$2f$app$2f5b$locale$5d2f28$marketing$292f$blog$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$apps$2f$web$2f$modules$2f$shared$2f$lib$2f$cache$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$exports$3e$__["7ffca56d615d22c5c3942bacb3c6b36d4da5e7c394"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f2e$next$2d$internal$2f$server$2f$app$2f5b$locale$5d2f28$marketing$292f$blog$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$apps$2f$web$2f$modules$2f$shared$2f$lib$2f$cache$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__('[project]/apps/web/.next-internal/server/app/[locale]/(marketing)/blog/page/actions.js { ACTIONS_MODULE0 => "[project]/apps/web/modules/shared/lib/cache.ts [app-rsc] (ecmascript)" } [app-rsc] (ecmascript) <module evaluation>');
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f2e$next$2d$internal$2f$server$2f$app$2f5b$locale$5d2f28$marketing$292f$blog$2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$apps$2f$web$2f$modules$2f$shared$2f$lib$2f$cache$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$exports$3e$__ = __turbopack_import__('[project]/apps/web/.next-internal/server/app/[locale]/(marketing)/blog/page/actions.js { ACTIONS_MODULE0 => "[project]/apps/web/modules/shared/lib/cache.ts [app-rsc] (ecmascript)" } [app-rsc] (ecmascript) <exports>');
}}),

};

//# sourceMappingURL=%5Bproject%5D_apps_web_bac59d._.js.map