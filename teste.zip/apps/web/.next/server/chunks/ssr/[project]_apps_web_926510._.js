module.exports = {

"[project]/apps/web/modules/marketing/blog/components/PostListItem.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "PostListItem": (()=>PostListItem)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-20241020__react@19.0.0-rc-65a56d0e-20241020/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$modules$2f$i18n$2f$routing$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/apps/web/modules/i18n/routing.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-20241020__react@19.0.0-rc-65a56d0e-20241020/node_modules/next/image.js [app-ssr] (ecmascript)");
"use client";
;
;
;
function PostListItem({ post }) {
    const { title, excerpt, authorName, image, date, path, authorImage, tags } = post;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "rounded-2xl border bg-card/50 p-6",
        children: [
            image && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "-mx-4 -mt-4 relative mb-4 aspect-[16/9] overflow-hidden rounded-xl",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        src: image,
                        alt: title,
                        fill: true,
                        sizes: "(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw",
                        className: "object-cover object-center"
                    }, void 0, false, {
                        fileName: "[project]/apps/web/modules/marketing/blog/components/PostListItem.tsx",
                        lineNumber: 15,
                        columnNumber: 6
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$modules$2f$i18n$2f$routing$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Link"], {
                        href: `/blog/${path}`,
                        className: "absolute inset-0"
                    }, void 0, false, {
                        fileName: "[project]/apps/web/modules/marketing/blog/components/PostListItem.tsx",
                        lineNumber: 22,
                        columnNumber: 6
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/web/modules/marketing/blog/components/PostListItem.tsx",
                lineNumber: 14,
                columnNumber: 5
            }, this),
            tags && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-2 flex flex-wrap gap-2",
                children: tags.map((tag)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "font-semibold text-primary text-xs uppercase tracking-wider",
                        children: [
                            "#",
                            tag
                        ]
                    }, tag, true, {
                        fileName: "[project]/apps/web/modules/marketing/blog/components/PostListItem.tsx",
                        lineNumber: 29,
                        columnNumber: 7
                    }, this))
            }, void 0, false, {
                fileName: "[project]/apps/web/modules/marketing/blog/components/PostListItem.tsx",
                lineNumber: 27,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$modules$2f$i18n$2f$routing$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Link"], {
                href: `/blog/${path}`,
                className: "font-semibold text-xl",
                children: title
            }, void 0, false, {
                fileName: "[project]/apps/web/modules/marketing/blog/components/PostListItem.tsx",
                lineNumber: 39,
                columnNumber: 4
            }, this),
            excerpt && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "opacity-50",
                children: excerpt
            }, void 0, false, {
                fileName: "[project]/apps/web/modules/marketing/blog/components/PostListItem.tsx",
                lineNumber: 42,
                columnNumber: 16
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-4 flex items-center justify-between",
                children: [
                    authorName && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center",
                        children: [
                            authorImage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "relative mr-2 size-8 overflow-hidden rounded-full",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    src: authorImage,
                                    alt: authorName,
                                    fill: true,
                                    sizes: "96px",
                                    className: "object-cover object-center"
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/modules/marketing/blog/components/PostListItem.tsx",
                                    lineNumber: 49,
                                    columnNumber: 9
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/apps/web/modules/marketing/blog/components/PostListItem.tsx",
                                lineNumber: 48,
                                columnNumber: 8
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "font-semibold text-sm opacity-50",
                                    children: authorName
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/modules/marketing/blog/components/PostListItem.tsx",
                                    lineNumber: 59,
                                    columnNumber: 8
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/apps/web/modules/marketing/blog/components/PostListItem.tsx",
                                lineNumber: 58,
                                columnNumber: 7
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/web/modules/marketing/blog/components/PostListItem.tsx",
                        lineNumber: 46,
                        columnNumber: 6
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mr-0 ml-auto",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-sm opacity-30",
                            children: Intl.DateTimeFormat("en-US").format(new Date(date))
                        }, void 0, false, {
                            fileName: "[project]/apps/web/modules/marketing/blog/components/PostListItem.tsx",
                            lineNumber: 65,
                            columnNumber: 6
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/apps/web/modules/marketing/blog/components/PostListItem.tsx",
                        lineNumber: 64,
                        columnNumber: 5
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/web/modules/marketing/blog/components/PostListItem.tsx",
                lineNumber: 44,
                columnNumber: 4
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/web/modules/marketing/blog/components/PostListItem.tsx",
        lineNumber: 12,
        columnNumber: 3
    }, this);
}
}}),
"[project]/apps/web/app/[locale]/(marketing)/blog/page.tsx [app-rsc] (ecmascript, Next.js server component, client modules ssr)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: require } = __turbopack_context__;
{
}}),

};

//# sourceMappingURL=%5Bproject%5D_apps_web_926510._.js.map