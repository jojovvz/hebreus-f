module.exports = {

"[project]/config.ts [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "config": (()=>config)
});
const config = {
    i18n: {
        locales: {
            en: {
                currency: "USD",
                label: "English"
            },
            de: {
                currency: "USD",
                label: "Deutsch"
            }
        },
        defaultLocale: "en",
        defaultCurrency: "USD",
        localeCookieName: "NEXT_LOCALE"
    },
    teams: {
        avatarColors: [
            "#4e6df5",
            "#e5a158",
            "#9dbee5",
            "#ced3d9"
        ]
    },
    auth: {
        redirectAfterLogout: "/",
        sessionCookieName: "auth_session",
        sessionCookieMaxAge: 60 * 60 * 24 * 30
    },
    mailing: {
        provider: "nodemailer",
        from: "contato@giovannimota.com.br"
    },
    ui: {
        enabledThemes: [
            "light",
            "dark"
        ],
        defaultTheme: "light"
    }
};
}}),
"[project]/apps/web/modules/i18n/routing.ts [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "Link": (()=>Link),
    "redirect": (()=>redirect),
    "routing": (()=>routing),
    "usePathname": (()=>usePathname),
    "useRouter": (()=>useRouter)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$config$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/config.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$intl$40$3$2e$25$2e$1_next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$2_femrh4wds34izboa6tviasui5q$2f$node_modules$2f$next$2d$intl$2f$dist$2f$routing$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/routing.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$intl$40$3$2e$25$2e$1_next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$2_femrh4wds34izboa6tviasui5q$2f$node_modules$2f$next$2d$intl$2f$dist$2f$navigation$2e$react$2d$client$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/navigation.react-client.js [app-ssr] (ecmascript)");
;
;
;
const routing = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$intl$40$3$2e$25$2e$1_next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$2_femrh4wds34izboa6tviasui5q$2f$node_modules$2f$next$2d$intl$2f$dist$2f$routing$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["defineRouting"])({
    locales: Object.keys(__TURBOPACK__imported__module__$5b$project$5d2f$config$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["config"].i18n.locales),
    defaultLocale: __TURBOPACK__imported__module__$5b$project$5d2f$config$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["config"].i18n.defaultLocale,
    localePrefix: "never",
    localeCookie: {
        name: __TURBOPACK__imported__module__$5b$project$5d2f$config$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["config"].i18n.localeCookieName
    }
});
const { Link, redirect, usePathname, useRouter } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$intl$40$3$2e$25$2e$1_next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$2_femrh4wds34izboa6tviasui5q$2f$node_modules$2f$next$2d$intl$2f$dist$2f$navigation$2e$react$2d$client$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createNavigation"])({
    locales: Object.keys(__TURBOPACK__imported__module__$5b$project$5d2f$config$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["config"].i18n.locales),
    localePrefix: "never",
    localeCookie: {
        name: __TURBOPACK__imported__module__$5b$project$5d2f$config$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["config"].i18n.localeCookieName
    }
});
}}),
"[project]/apps/web/modules/ui/components/button.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "Button": (()=>Button),
    "buttonVariants": (()=>buttonVariants)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-20241020__react@19.0.0-rc-65a56d0e-20241020/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-20241020__react@19.0.0-rc-65a56d0e-20241020/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$modules$2f$ui$2f$lib$2f$index$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/apps/web/modules/ui/lib/index.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$class$2d$variance$2d$authority$40$0$2e$7$2e$1$2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/class-variance-authority@0.7.1/node_modules/class-variance-authority/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$slot$40$1$2e$1$2e$0_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_types$2d$react$40$19$2e$0$2e$0$2d$rc$2e$1$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/@radix-ui+react-slot@1.1.0_react@19.0.0-rc-65a56d0e-20241020_types-react@19.0.0-rc.1/node_modules/@radix-ui/react-slot/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$462$2e$0_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__LoaderIcon$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/lucide-react@0.462.0_react@19.0.0-rc-65a56d0e-20241020/node_modules/lucide-react/dist/esm/icons/loader.js [app-ssr] (ecmascript) <export default as LoaderIcon>");
;
;
;
;
;
;
const buttonVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$class$2d$variance$2d$authority$40$0$2e$7$2e$1$2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cva"])("flex items-center justify-center font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:pointer-events-none disabled:opacity-50", {
    variants: {
        variant: {
            default: "bg-primary text-primary-foreground hover:bg-primary/90",
            error: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
            outline: "border border-secondary/15 bg-transparent text-secondary hover:bg-secondary/10",
            secondary: "border-secondary bg-secondary text-secondary-foreground hover:bg-secondary/80",
            ghost: "border-transparent text-primary hover:bg-primary/10 hover:text-primary",
            link: "border-transparent text-primary underline-offset-4 hover:underline"
        },
        size: {
            default: "h-10 rounded-lg px-4 text-sm",
            sm: "h-8 rounded-md px-3 text-xs",
            lg: "h-12 rounded-xl px-6 text-base",
            icon: "size-10 rounded-lg"
        }
    },
    defaultVariants: {
        variant: "default",
        size: "default"
    }
});
const Button = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__.forwardRef(({ className, children, variant, size, asChild = false, loading, disabled, ...props }, ref)=>{
    const Comp = asChild ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$radix$2d$ui$2b$react$2d$slot$40$1$2e$1$2e$0_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_types$2d$react$40$19$2e$0$2e$0$2d$rc$2e$1$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Slot"] : "button";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Comp, {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$modules$2f$ui$2f$lib$2f$index$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])(buttonVariants({
            variant,
            size,
            className
        })),
        ref: ref,
        disabled: disabled ?? loading,
        ...props,
        children: loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$462$2e$0_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__LoaderIcon$3e$__["LoaderIcon"], {
            className: "size-4 animate-spin"
        }, void 0, false, {
            fileName: "[project]/apps/web/modules/ui/components/button.tsx",
            lineNumber: 67,
            columnNumber: 16
        }, this) : children
    }, void 0, false, {
        fileName: "[project]/apps/web/modules/ui/components/button.tsx",
        lineNumber: 61,
        columnNumber: 4
    }, this);
});
Button.displayName = "Button";
;
}}),
"[project]/apps/web/modules/marketing/shared/components/NotFound.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "NotFound": (()=>NotFound)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-20241020__react@19.0.0-rc-65a56d0e-20241020/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$modules$2f$i18n$2f$routing$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/apps/web/modules/i18n/routing.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$modules$2f$ui$2f$components$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/apps/web/modules/ui/components/button.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$462$2e$0_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$undo$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__UndoIcon$3e$__ = __turbopack_import__("[project]/node_modules/.pnpm/lucide-react@0.462.0_react@19.0.0-rc-65a56d0e-20241020/node_modules/lucide-react/dist/esm/icons/undo.js [app-ssr] (ecmascript) <export default as UndoIcon>");
"use client";
;
;
;
;
function NotFound() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex h-screen flex-col items-center justify-center",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "font-bold text-5xl",
                children: "404"
            }, void 0, false, {
                fileName: "[project]/apps/web/modules/marketing/shared/components/NotFound.tsx",
                lineNumber: 10,
                columnNumber: 4
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-2 text-2xl",
                children: "Page not found"
            }, void 0, false, {
                fileName: "[project]/apps/web/modules/marketing/shared/components/NotFound.tsx",
                lineNumber: 11,
                columnNumber: 4
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$modules$2f$ui$2f$components$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                asChild: true,
                className: "mt-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$modules$2f$i18n$2f$routing$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Link"], {
                    href: "/",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$0$2e$3_react$2d$dom$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020_$5f$react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$462$2e$0_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$undo$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__UndoIcon$3e$__["UndoIcon"], {
                            className: "mr-2 size-4"
                        }, void 0, false, {
                            fileName: "[project]/apps/web/modules/marketing/shared/components/NotFound.tsx",
                            lineNumber: 15,
                            columnNumber: 6
                        }, this),
                        " Go to homepage"
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/web/modules/marketing/shared/components/NotFound.tsx",
                    lineNumber: 14,
                    columnNumber: 5
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/web/modules/marketing/shared/components/NotFound.tsx",
                lineNumber: 13,
                columnNumber: 4
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/web/modules/marketing/shared/components/NotFound.tsx",
        lineNumber: 9,
        columnNumber: 3
    }, this);
}
}}),
"[project]/apps/web/app/[locale]/[...rest]/page.tsx [app-rsc] (ecmascript, Next.js server component, client modules ssr)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: require } = __turbopack_context__;
{
}}),
"[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/routing/defineRouting.js [app-ssr] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: require } = __turbopack_context__;
{
'use strict';
Object.defineProperty(exports, '__esModule', {
    value: true
});
function defineRouting(config) {
    return config;
}
exports.default = defineRouting;
}}),
"[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/routing.js [app-ssr] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: require } = __turbopack_context__;
{
'use strict';
Object.defineProperty(exports, '__esModule', {
    value: true
});
var defineRouting = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/routing/defineRouting.js [app-ssr] (ecmascript)");
exports.defineRouting = defineRouting.default;
}}),
"[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/routing.js [app-ssr] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: require } = __turbopack_context__;
{
'use strict';
if ("TURBOPACK compile-time falsy", 0) {
    "TURBOPACK unreachable";
} else {
    module.exports = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/routing.js [app-ssr] (ecmascript)");
}
}}),
"[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/_virtual/_rollupPluginBabelHelpers.js [app-ssr] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: require } = __turbopack_context__;
{
'use strict';
Object.defineProperty(exports, '__esModule', {
    value: true
});
function _extends() {
    return _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined), _extends.apply(null, arguments);
}
exports.extends = _extends;
}}),
"[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/routing/config.js [app-ssr] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: require } = __turbopack_context__;
{
'use strict';
Object.defineProperty(exports, '__esModule', {
    value: true
});
function receiveRoutingConfig(input) {
    var _input$localeDetectio, _input$alternateLinks;
    return {
        ...input,
        localePrefix: receiveLocalePrefixConfig(input.localePrefix),
        localeCookie: receiveLocaleCookie(input.localeCookie),
        localeDetection: (_input$localeDetectio = input.localeDetection) !== null && _input$localeDetectio !== void 0 ? _input$localeDetectio : true,
        alternateLinks: (_input$alternateLinks = input.alternateLinks) !== null && _input$alternateLinks !== void 0 ? _input$alternateLinks : true
    };
}
function receiveLocaleCookie(localeCookie) {
    return (localeCookie !== null && localeCookie !== void 0 ? localeCookie : true) ? {
        name: 'NEXT_LOCALE',
        maxAge: 31536000,
        // 1 year
        sameSite: 'lax',
        ...typeof localeCookie === 'object' && localeCookie
    } : false;
}
function receiveLocalePrefixConfig(localePrefix) {
    return typeof localePrefix === 'object' ? localePrefix : {
        mode: localePrefix || 'always'
    };
}
exports.receiveLocaleCookie = receiveLocaleCookie;
exports.receiveLocalePrefixConfig = receiveLocalePrefixConfig;
exports.receiveRoutingConfig = receiveRoutingConfig;
}}),
"[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/shared/constants.js [app-ssr] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: require } = __turbopack_context__;
{
'use strict';
Object.defineProperty(exports, '__esModule', {
    value: true
});
// Should take precedence over the cookie
const HEADER_LOCALE_NAME = 'X-NEXT-INTL-LOCALE';
// In a URL like "/en-US/about", the locale segment is "en-US"
const LOCALE_SEGMENT_NAME = 'locale';
exports.HEADER_LOCALE_NAME = HEADER_LOCALE_NAME;
exports.LOCALE_SEGMENT_NAME = LOCALE_SEGMENT_NAME;
}}),
"[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/react-client/useLocale.js [app-ssr] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: require } = __turbopack_context__;
{
'use strict';
Object.defineProperty(exports, '__esModule', {
    value: true
});
var navigation = __turbopack_require__("[project]/node_modules/.pnpm/next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-20241020__react@19.0.0-rc-65a56d0e-20241020/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var _useLocale = __turbopack_require__("[project]/node_modules/.pnpm/use-intl@3.25.1_react@19.0.0-rc-65a56d0e-20241020/node_modules/use-intl/dist/_useLocale.js [app-ssr] (ecmascript)");
var constants = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/shared/constants.js [app-ssr] (ecmascript)");
function useLocale() {
    // The types aren't entirely correct here. Outside of Next.js
    // `useParams` can be called, but the return type is `null`.
    const params = navigation.useParams();
    let locale;
    try {
        // eslint-disable-next-line react-compiler/react-compiler
        // eslint-disable-next-line react-hooks/rules-of-hooks, react-compiler/react-compiler -- False positive
        locale = _useLocale.useLocale();
    } catch (error) {
        if (typeof (params === null || params === void 0 ? void 0 : params[constants.LOCALE_SEGMENT_NAME]) === 'string') {
            locale = params[constants.LOCALE_SEGMENT_NAME];
        } else {
            throw error;
        }
    }
    return locale;
}
exports.default = useLocale;
}}),
"[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/shared/utils.js [app-ssr] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: require } = __turbopack_context__;
{
'use strict';
Object.defineProperty(exports, '__esModule', {
    value: true
});
function isRelativeHref(href) {
    const pathname = typeof href === 'object' ? href.pathname : href;
    return pathname != null && !pathname.startsWith('/');
}
function isLocalHref(href) {
    if (typeof href === 'object') {
        return href.host == null && href.hostname == null;
    } else {
        const hasProtocol = /^[a-z]+:/i.test(href);
        return !hasProtocol;
    }
}
function isLocalizableHref(href) {
    return isLocalHref(href) && !isRelativeHref(href);
}
function localizeHref(href, locale) {
    let curLocale = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : locale;
    let curPathname = arguments.length > 3 ? arguments[3] : undefined;
    let prefix = arguments.length > 4 ? arguments[4] : undefined;
    if (!isLocalizableHref(href)) {
        return href;
    }
    const isSwitchingLocale = locale !== curLocale;
    const isPathnamePrefixed = hasPathnamePrefixed(prefix, curPathname);
    const shouldPrefix = isSwitchingLocale || isPathnamePrefixed;
    if (shouldPrefix && prefix != null) {
        return prefixHref(href, prefix);
    }
    return href;
}
function prefixHref(href, prefix) {
    let prefixedHref;
    if (typeof href === 'string') {
        prefixedHref = prefixPathname(prefix, href);
    } else {
        prefixedHref = {
            ...href
        };
        if (href.pathname) {
            prefixedHref.pathname = prefixPathname(prefix, href.pathname);
        }
    }
    return prefixedHref;
}
function unprefixPathname(pathname, prefix) {
    return pathname.replace(new RegExp("^".concat(prefix)), '') || '/';
}
function prefixPathname(prefix, pathname) {
    let localizedHref = prefix;
    // Avoid trailing slashes
    if (/^\/(\?.*)?$/.test(pathname)) {
        pathname = pathname.slice(1);
    }
    localizedHref += pathname;
    return localizedHref;
}
function hasPathnamePrefixed(prefix, pathname) {
    return pathname === prefix || pathname.startsWith("".concat(prefix, "/"));
}
function hasTrailingSlash() {
    try {
        // Provided via `env` setting in `next.config.js` via the plugin
        return process.env._next_intl_trailing_slash === 'true';
    } catch (_unused) {
        return false;
    }
}
function normalizeTrailingSlash(pathname) {
    const trailingSlash = hasTrailingSlash();
    if (pathname !== '/') {
        const pathnameEndsWithSlash = pathname.endsWith('/');
        if (trailingSlash && !pathnameEndsWithSlash) {
            pathname += '/';
        } else if (!trailingSlash && pathnameEndsWithSlash) {
            pathname = pathname.slice(0, -1);
        }
    }
    return pathname;
}
function matchesPathname(/** E.g. `/users/[userId]-[userName]` */ template, /** E.g. `/users/23-jane` */ pathname) {
    const normalizedTemplate = normalizeTrailingSlash(template);
    const normalizedPathname = normalizeTrailingSlash(pathname);
    const regex = templateToRegex(normalizedTemplate);
    return regex.test(normalizedPathname);
}
function getLocalePrefix(locale, localePrefix) {
    var _localePrefix$prefixe;
    return localePrefix.mode !== 'never' && ((_localePrefix$prefixe = localePrefix.prefixes) === null || _localePrefix$prefixe === void 0 ? void 0 : _localePrefix$prefixe[locale]) || // We return a prefix even if `mode: 'never'`. It's up to the consumer
    // to decide to use it or not.
    '/' + locale;
}
function templateToRegex(template) {
    const regexPattern = template// Replace optional catchall ('[[...slug]]')
    .replace(/\[\[(\.\.\.[^\]]+)\]\]/g, '?(.*)')// Replace catchall ('[...slug]')
    .replace(/\[(\.\.\.[^\]]+)\]/g, '(.+)')// Replace regular parameter ('[slug]')
    .replace(/\[([^\]]+)\]/g, '([^/]+)');
    return new RegExp("^".concat(regexPattern, "$"));
}
function isOptionalCatchAllSegment(pathname) {
    return pathname.includes('[[...');
}
function isCatchAllSegment(pathname) {
    return pathname.includes('[...');
}
function isDynamicSegment(pathname) {
    return pathname.includes('[');
}
function comparePathnamePairs(a, b) {
    const pathA = a.split('/');
    const pathB = b.split('/');
    const maxLength = Math.max(pathA.length, pathB.length);
    for(let i = 0; i < maxLength; i++){
        const segmentA = pathA[i];
        const segmentB = pathB[i];
        // If one of the paths ends, prioritize the shorter path
        if (!segmentA && segmentB) return -1;
        if (segmentA && !segmentB) return 1;
        if (!segmentA && !segmentB) continue;
        // Prioritize static segments over dynamic segments
        if (!isDynamicSegment(segmentA) && isDynamicSegment(segmentB)) return -1;
        if (isDynamicSegment(segmentA) && !isDynamicSegment(segmentB)) return 1;
        // Prioritize non-catch-all segments over catch-all segments
        if (!isCatchAllSegment(segmentA) && isCatchAllSegment(segmentB)) return -1;
        if (isCatchAllSegment(segmentA) && !isCatchAllSegment(segmentB)) return 1;
        // Prioritize non-optional catch-all segments over optional catch-all segments
        if (!isOptionalCatchAllSegment(segmentA) && isOptionalCatchAllSegment(segmentB)) {
            return -1;
        }
        if (isOptionalCatchAllSegment(segmentA) && !isOptionalCatchAllSegment(segmentB)) {
            return 1;
        }
        if (segmentA === segmentB) continue;
    }
    // Both pathnames are completely static
    return 0;
}
function getSortedPathnames(pathnames) {
    return pathnames.sort(comparePathnamePairs);
}
exports.getLocalePrefix = getLocalePrefix;
exports.getSortedPathnames = getSortedPathnames;
exports.hasPathnamePrefixed = hasPathnamePrefixed;
exports.isLocalizableHref = isLocalizableHref;
exports.localizeHref = localizeHref;
exports.matchesPathname = matchesPathname;
exports.normalizeTrailingSlash = normalizeTrailingSlash;
exports.prefixHref = prefixHref;
exports.prefixPathname = prefixPathname;
exports.templateToRegex = templateToRegex;
exports.unprefixPathname = unprefixPathname;
}}),
"[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/shared/utils.js [app-ssr] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: require } = __turbopack_context__;
{
'use strict';
Object.defineProperty(exports, '__esModule', {
    value: true
});
var utils = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/shared/utils.js [app-ssr] (ecmascript)");
// Minor false positive: A route that has both optional and
// required params will allow optional params.
// For `Link`
// For `getPathname` (hence also its consumers: `redirect`, `useRouter`, …)
function normalizeNameOrNameWithParams(href) {
    return typeof href === 'string' ? {
        pathname: href
    } : href;
}
function serializeSearchParams(searchParams) {
    function serializeValue(value) {
        return String(value);
    }
    const urlSearchParams = new URLSearchParams();
    for (const [key, value] of Object.entries(searchParams)){
        if (Array.isArray(value)) {
            value.forEach((cur)=>{
                urlSearchParams.append(key, serializeValue(cur));
            });
        } else {
            urlSearchParams.set(key, serializeValue(value));
        }
    }
    return '?' + urlSearchParams.toString();
}
function compileLocalizedPathname(_ref) {
    let { pathname, locale, params, pathnames, query } = _ref;
    function getNamedPath(value) {
        let namedPath = pathnames[value];
        if (!namedPath) {
            // Unknown pathnames
            namedPath = value;
        }
        return namedPath;
    }
    function compilePath(namedPath) {
        const template = typeof namedPath === 'string' ? namedPath : namedPath[locale];
        let compiled = template;
        if (params) {
            Object.entries(params).forEach((_ref2)=>{
                let [key, value] = _ref2;
                let regexp, replacer;
                if (Array.isArray(value)) {
                    regexp = "(\\[)?\\[...".concat(key, "\\](\\])?");
                    replacer = value.map((v)=>String(v)).join('/');
                } else {
                    regexp = "\\[".concat(key, "\\]");
                    replacer = String(value);
                }
                compiled = compiled.replace(new RegExp(regexp, 'g'), replacer);
            });
        }
        // Clean up optional catch-all segments that were not replaced
        compiled = compiled.replace(/\[\[\.\.\..+\]\]/g, '');
        compiled = utils.normalizeTrailingSlash(compiled);
        if (compiled.includes('[')) {
            // Next.js throws anyway, therefore better provide a more helpful error message
            throw new Error("Insufficient params provided for localized pathname.\nTemplate: ".concat(template, "\nParams: ").concat(JSON.stringify(params)));
        }
        if (query) {
            compiled += serializeSearchParams(query);
        }
        return compiled;
    }
    if (typeof pathname === 'string') {
        const namedPath = getNamedPath(pathname);
        const compiled = compilePath(namedPath);
        return compiled;
    } else {
        const { pathname: href, ...rest } = pathname;
        const namedPath = getNamedPath(href);
        const compiled = compilePath(namedPath);
        const result = {
            ...rest,
            pathname: compiled
        };
        return result;
    }
}
function getRoute(locale, pathname, pathnames) {
    const sortedPathnames = utils.getSortedPathnames(Object.keys(pathnames));
    const decoded = decodeURI(pathname);
    for (const internalPathname of sortedPathnames){
        const localizedPathnamesOrPathname = pathnames[internalPathname];
        if (typeof localizedPathnamesOrPathname === 'string') {
            const localizedPathname = localizedPathnamesOrPathname;
            if (utils.matchesPathname(localizedPathname, decoded)) {
                return internalPathname;
            }
        } else {
            if (utils.matchesPathname(localizedPathnamesOrPathname[locale], decoded)) {
                return internalPathname;
            }
        }
    }
    return pathname;
}
function getBasePath(pathname) {
    let windowPathname = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : window.location.pathname;
    if (pathname === '/') {
        return windowPathname;
    } else {
        return windowPathname.replace(pathname, '');
    }
}
function applyPathnamePrefix(pathname, locale, routing, domain, force) {
    const { mode } = routing.localePrefix;
    let shouldPrefix;
    if (force !== undefined) {
        shouldPrefix = force;
    } else if (utils.isLocalizableHref(pathname)) {
        if (mode === 'always') {
            shouldPrefix = true;
        } else if (mode === 'as-needed') {
            let defaultLocale = routing.defaultLocale;
            if (routing.domains) {
                const domainConfig = routing.domains.find((cur)=>cur.domain === domain);
                if (domainConfig) {
                    defaultLocale = domainConfig.defaultLocale;
                } else {
                    if (!domain) {
                        console.error("You're using a routing configuration with `localePrefix: 'as-needed'` in combination with `domains`. In order to compute a correct pathname, you need to provide a `domain` parameter.\n\nSee: https://next-intl-docs.vercel.app/docs/routing#domains-localeprefix-asneeded");
                    }
                }
            }
            shouldPrefix = defaultLocale !== locale;
        }
    }
    return shouldPrefix ? utils.prefixPathname(utils.getLocalePrefix(locale, routing.localePrefix), pathname) : pathname;
}
function validateReceivedConfig(config) {
    var _config$localePrefix;
    if (((_config$localePrefix = config.localePrefix) === null || _config$localePrefix === void 0 ? void 0 : _config$localePrefix.mode) === 'as-needed' && !('defaultLocale' in config)) {
        throw new Error("`localePrefix: 'as-needed' requires a `defaultLocale`.");
    }
}
exports.applyPathnamePrefix = applyPathnamePrefix;
exports.compileLocalizedPathname = compileLocalizedPathname;
exports.getBasePath = getBasePath;
exports.getRoute = getRoute;
exports.normalizeNameOrNameWithParams = normalizeNameOrNameWithParams;
exports.serializeSearchParams = serializeSearchParams;
exports.validateReceivedConfig = validateReceivedConfig;
}}),
"[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/shared/syncLocaleCookie.js [app-ssr] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: require } = __turbopack_context__;
{
'use strict';
Object.defineProperty(exports, '__esModule', {
    value: true
});
var utils = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/shared/utils.js [app-ssr] (ecmascript)");
/**
 * We have to keep the cookie value in sync as Next.js might
 * skip a request to the server due to its router cache.
 * See https://github.com/amannn/next-intl/issues/786.
 */ function syncLocaleCookie(localeCookie, pathname, locale, nextLocale) {
    const isSwitchingLocale = nextLocale !== locale && nextLocale != null;
    if (!localeCookie || !isSwitchingLocale || // Theoretical case, we always have a pathname in a real app,
    // only not when running e.g. in a simulated test environment
    !pathname) {
        return;
    }
    const basePath = utils.getBasePath(pathname);
    const hasBasePath = basePath !== '';
    const defaultPath = hasBasePath ? basePath : '/';
    const { name, ...rest } = localeCookie;
    if (!rest.path) {
        rest.path = defaultPath;
    }
    let localeCookieString = "".concat(name, "=").concat(nextLocale, ";");
    for (const [key, value] of Object.entries(rest)){
        // Map object properties to cookie properties.
        // Interestingly, `maxAge` corresponds to `max-age`,
        // while `sameSite` corresponds to `SameSite`.
        // Also, keys are case-insensitive.
        const targetKey = key === 'maxAge' ? 'max-age' : key;
        localeCookieString += "".concat(targetKey);
        if (typeof value !== 'boolean') {
            localeCookieString += '=' + value;
        }
        // A trailing ";" is allowed by browsers
        localeCookieString += ';';
    }
    // Note that writing to `document.cookie` doesn't overwrite all
    // cookies, but only the ones referenced via the name here.
    document.cookie = localeCookieString;
}
exports.default = syncLocaleCookie;
}}),
"[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/shared/BaseLink.js [app-ssr] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: require } = __turbopack_context__;
{
"use client";
'use strict';
Object.defineProperty(exports, '__esModule', {
    value: true
});
var _rollupPluginBabelHelpers = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/_virtual/_rollupPluginBabelHelpers.js [app-ssr] (ecmascript)");
var NextLink = __turbopack_require__("[project]/node_modules/.pnpm/next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-20241020__react@19.0.0-rc-65a56d0e-20241020/node_modules/next/link.js [app-ssr] (ecmascript)");
var navigation = __turbopack_require__("[project]/node_modules/.pnpm/next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-20241020__react@19.0.0-rc-65a56d0e-20241020/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var React = __turbopack_require__("[project]/node_modules/.pnpm/next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-20241020__react@19.0.0-rc-65a56d0e-20241020/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var useLocale = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/react-client/useLocale.js [app-ssr] (ecmascript)");
var syncLocaleCookie = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/shared/syncLocaleCookie.js [app-ssr] (ecmascript)");
function _interopDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}
var NextLink__default = /*#__PURE__*/ _interopDefault(NextLink);
var React__default = /*#__PURE__*/ _interopDefault(React);
function BaseLink(_ref, ref) {
    let { defaultLocale, href, locale, localeCookie, onClick, prefetch, unprefixed, ...rest } = _ref;
    const curLocale = useLocale.default();
    const isChangingLocale = locale != null && locale !== curLocale;
    const linkLocale = locale || curLocale;
    const host = useHost();
    const finalHref = // Only after hydration (to avoid mismatches)
    host && // If there is an `unprefixed` prop, the
    // `defaultLocale` might differ by domain
    unprefixed && (// Unprefix the pathname if a domain matches
    unprefixed.domains[host] === linkLocale || // … and handle unknown domains by applying the
    // global `defaultLocale` (e.g. on localhost)
    !Object.keys(unprefixed.domains).includes(host) && curLocale === defaultLocale && !locale) ? unprefixed.pathname : href;
    // The types aren't entirely correct here. Outside of Next.js
    // `useParams` can be called, but the return type is `null`.
    const pathname = navigation.usePathname();
    function onLinkClick(event) {
        syncLocaleCookie.default(localeCookie, pathname, curLocale, locale);
        if (onClick) onClick(event);
    }
    if (isChangingLocale) {
        if (prefetch && "development" !== 'production') {
            console.error('The `prefetch` prop is currently not supported when using the `locale` prop on `Link` to switch the locale.`');
        }
        prefetch = false;
    }
    return /*#__PURE__*/ React__default.default.createElement(NextLink__default.default, _rollupPluginBabelHelpers.extends({
        ref: ref,
        href: finalHref,
        hrefLang: isChangingLocale ? locale : undefined,
        onClick: onLinkClick,
        prefetch: prefetch
    }, rest));
}
function useHost() {
    const [host, setHost] = React.useState();
    React.useEffect(()=>{
        setHost(window.location.host);
    }, []);
    return host;
}
var BaseLink$1 = /*#__PURE__*/ React.forwardRef(BaseLink);
exports.default = BaseLink$1;
}}),
"[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/shared/LegacyBaseLink.js [app-ssr] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: require } = __turbopack_context__;
{
"use client";
'use strict';
Object.defineProperty(exports, '__esModule', {
    value: true
});
var _rollupPluginBabelHelpers = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/_virtual/_rollupPluginBabelHelpers.js [app-ssr] (ecmascript)");
var navigation = __turbopack_require__("[project]/node_modules/.pnpm/next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-20241020__react@19.0.0-rc-65a56d0e-20241020/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var React = __turbopack_require__("[project]/node_modules/.pnpm/next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-20241020__react@19.0.0-rc-65a56d0e-20241020/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var useLocale = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/react-client/useLocale.js [app-ssr] (ecmascript)");
var utils = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/shared/utils.js [app-ssr] (ecmascript)");
var BaseLink = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/shared/BaseLink.js [app-ssr] (ecmascript)");
function _interopDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}
var React__default = /*#__PURE__*/ _interopDefault(React);
function LegacyBaseLink(_ref, ref) {
    let { href, locale, localeCookie, localePrefixMode, prefix, ...rest } = _ref;
    // The types aren't entirely correct here. Outside of Next.js
    // `useParams` can be called, but the return type is `null`.
    const pathname = navigation.usePathname();
    const curLocale = useLocale.default();
    const isChangingLocale = locale !== curLocale;
    const [localizedHref, setLocalizedHref] = React.useState(()=>utils.isLocalizableHref(href) && (localePrefixMode !== 'never' || isChangingLocale) ? // For the `localePrefix: 'as-needed' strategy, the href shouldn't
        // be prefixed if the locale is the default locale. To determine this, we
        // need a) the default locale and b) the information if we use prefixed
        // routing. The default locale can vary by domain, therefore during the
        // RSC as well as the SSR render, we can't determine the default locale
        // statically. Therefore we always prefix the href since this will
        // always result in a valid URL, even if it might cause a redirect. This
        // is better than pointing to a non-localized href during the server
        // render, which would potentially be wrong. The final href is
        // determined in the effect below.
        utils.prefixHref(href, prefix) : href);
    React.useEffect(()=>{
        if (!pathname) return;
        setLocalizedHref(utils.localizeHref(href, locale, curLocale, pathname, prefix));
    }, [
        curLocale,
        href,
        locale,
        pathname,
        prefix
    ]);
    return /*#__PURE__*/ React__default.default.createElement(BaseLink.default, _rollupPluginBabelHelpers.extends({
        ref: ref,
        href: localizedHref,
        locale: locale,
        localeCookie: localeCookie
    }, rest));
}
const LegacyBaseLinkWithRef = /*#__PURE__*/ React.forwardRef(LegacyBaseLink);
LegacyBaseLinkWithRef.displayName = 'ClientLink';
exports.default = LegacyBaseLinkWithRef;
}}),
"[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/react-client/ClientLink.js [app-ssr] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: require } = __turbopack_context__;
{
'use strict';
Object.defineProperty(exports, '__esModule', {
    value: true
});
var _rollupPluginBabelHelpers = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/_virtual/_rollupPluginBabelHelpers.js [app-ssr] (ecmascript)");
var React = __turbopack_require__("[project]/node_modules/.pnpm/next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-20241020__react@19.0.0-rc-65a56d0e-20241020/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var useLocale = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/react-client/useLocale.js [app-ssr] (ecmascript)");
var utils = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/shared/utils.js [app-ssr] (ecmascript)");
var LegacyBaseLink = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/shared/LegacyBaseLink.js [app-ssr] (ecmascript)");
function _interopDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}
var React__default = /*#__PURE__*/ _interopDefault(React);
function ClientLink(_ref, ref) {
    let { locale, localePrefix, ...rest } = _ref;
    const defaultLocale = useLocale.default();
    const finalLocale = locale || defaultLocale;
    const prefix = utils.getLocalePrefix(finalLocale, localePrefix);
    return /*#__PURE__*/ React__default.default.createElement(LegacyBaseLink.default, _rollupPluginBabelHelpers.extends({
        ref: ref,
        locale: finalLocale,
        localePrefixMode: localePrefix.mode,
        prefix: prefix
    }, rest));
}
/**
 * Wraps `next/link` and prefixes the `href` with the current locale if
 * necessary.
 *
 * @example
 * ```tsx
 * import {Link} from 'next-intl';
 *
 * // When the user is on `/en`, the link will point to `/en/about`
 * <Link href="/about">About</Link>
 *
 * // You can override the `locale` to switch to another language
 * <Link href="/" locale="de">Switch to German</Link>
 * ```
 *
 * Note that when a `locale` prop is passed to switch the locale, the `prefetch`
 * prop is not supported. This is because Next.js would prefetch the page and
 * the `set-cookie` response header would cause the locale cookie on the current
 * page to be overwritten before the user even decides to change the locale.
 */ const ClientLinkWithRef = /*#__PURE__*/ React.forwardRef(ClientLink);
ClientLinkWithRef.displayName = 'ClientLink';
exports.default = ClientLinkWithRef;
}}),
"[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/shared/redirects.js [app-ssr] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: require } = __turbopack_context__;
{
'use strict';
Object.defineProperty(exports, '__esModule', {
    value: true
});
var navigation = __turbopack_require__("[project]/node_modules/.pnpm/next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-20241020__react@19.0.0-rc-65a56d0e-20241020/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var utils = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/shared/utils.js [app-ssr] (ecmascript)");
function createRedirectFn(redirectFn) {
    return function baseRedirect(params) {
        const prefix = utils.getLocalePrefix(params.locale, params.localePrefix);
        // This logic is considered legacy and is replaced by `applyPathnamePrefix`.
        // We keep it this way for now for backwards compatibility.
        const localizedPathname = params.localePrefix.mode === 'never' || !utils.isLocalizableHref(params.pathname) ? params.pathname : utils.prefixPathname(prefix, params.pathname);
        for(var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++){
            args[_key - 1] = arguments[_key];
        }
        return redirectFn(localizedPathname, ...args);
    };
}
const baseRedirect = createRedirectFn(navigation.redirect);
const basePermanentRedirect = createRedirectFn(navigation.permanentRedirect);
exports.basePermanentRedirect = basePermanentRedirect;
exports.baseRedirect = baseRedirect;
}}),
"[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/react-client/redirects.js [app-ssr] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: require } = __turbopack_context__;
{
'use strict';
Object.defineProperty(exports, '__esModule', {
    value: true
});
var useLocale = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/react-client/useLocale.js [app-ssr] (ecmascript)");
var redirects = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/shared/redirects.js [app-ssr] (ecmascript)");
function createRedirectFn(redirectFn) {
    return function clientRedirect(params) {
        let locale;
        try {
            // eslint-disable-next-line react-hooks/rules-of-hooks -- Reading from context here is fine, since `redirect` should be called during render
            locale = useLocale.default();
        } catch (e) {
            {
                throw new Error('`redirect()` and `permanentRedirect()` can only be called during render. To redirect in an event handler or similar, you can use `useRouter()` instead.');
            }
        }
        for(var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++){
            args[_key - 1] = arguments[_key];
        }
        return redirectFn({
            ...params,
            locale
        }, ...args);
    };
}
const clientRedirect = createRedirectFn(redirects.baseRedirect);
const clientPermanentRedirect = createRedirectFn(redirects.basePermanentRedirect);
exports.clientPermanentRedirect = clientPermanentRedirect;
exports.clientRedirect = clientRedirect;
}}),
"[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/react-client/useBasePathname.js [app-ssr] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: require } = __turbopack_context__;
{
'use strict';
Object.defineProperty(exports, '__esModule', {
    value: true
});
var navigation = __turbopack_require__("[project]/node_modules/.pnpm/next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-20241020__react@19.0.0-rc-65a56d0e-20241020/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var React = __turbopack_require__("[project]/node_modules/.pnpm/next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-20241020__react@19.0.0-rc-65a56d0e-20241020/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var useLocale = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/react-client/useLocale.js [app-ssr] (ecmascript)");
var utils = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/shared/utils.js [app-ssr] (ecmascript)");
function useBasePathname(localePrefix) {
    // The types aren't entirely correct here. Outside of Next.js
    // `useParams` can be called, but the return type is `null`.
    // Notes on `useNextPathname`:
    // - Types aren't entirely correct. Outside of Next.js the
    //   hook will return `null` (e.g. unit tests)
    // - A base path is stripped from the result
    // - Rewrites *are* taken into account (i.e. the pathname
    //   that the user sees in the browser is returned)
    const pathname = navigation.usePathname();
    const locale = useLocale.default();
    return React.useMemo(()=>{
        if (!pathname) return pathname;
        const prefix = utils.getLocalePrefix(locale, localePrefix);
        const isPathnamePrefixed = utils.hasPathnamePrefixed(prefix, pathname);
        const unlocalizedPathname = isPathnamePrefixed ? utils.unprefixPathname(pathname, prefix) : pathname;
        return unlocalizedPathname;
    }, [
        locale,
        localePrefix,
        pathname
    ]);
}
exports.default = useBasePathname;
}}),
"[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/react-client/useBaseRouter.js [app-ssr] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: require } = __turbopack_context__;
{
'use strict';
Object.defineProperty(exports, '__esModule', {
    value: true
});
var navigation = __turbopack_require__("[project]/node_modules/.pnpm/next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-20241020__react@19.0.0-rc-65a56d0e-20241020/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var React = __turbopack_require__("[project]/node_modules/.pnpm/next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-20241020__react@19.0.0-rc-65a56d0e-20241020/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var useLocale = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/react-client/useLocale.js [app-ssr] (ecmascript)");
var utils$1 = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/shared/utils.js [app-ssr] (ecmascript)");
var syncLocaleCookie = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/shared/syncLocaleCookie.js [app-ssr] (ecmascript)");
var utils = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/shared/utils.js [app-ssr] (ecmascript)");
/**
 * Returns a wrapped instance of `useRouter` from `next/navigation` that
 * will automatically localize the `href` parameters it receives.
 *
 * @example
 * ```tsx
 * 'use client';
 *
 * import {useRouter} from 'next-intl/client';
 *
 * const router = useRouter();
 *
 * // When the user is on `/en`, the router will navigate to `/en/about`
 * router.push('/about');
 *
 * // Optionally, you can switch the locale by passing the second argument
 * router.push('/about', {locale: 'de'});
 * ```
 */ function useBaseRouter(localePrefix, localeCookie) {
    const router = navigation.useRouter();
    const locale = useLocale.default();
    const pathname = navigation.usePathname();
    return React.useMemo(()=>{
        function localize(href, nextLocale) {
            let curPathname = window.location.pathname;
            const basePath = utils.getBasePath(pathname);
            if (basePath) curPathname = curPathname.replace(basePath, '');
            const targetLocale = nextLocale || locale;
            // We generate a prefix in any case, but decide
            // in `localizeHref` if we apply it or not
            const prefix = utils$1.getLocalePrefix(targetLocale, localePrefix);
            return utils$1.localizeHref(href, targetLocale, locale, curPathname, prefix);
        }
        function createHandler(fn) {
            return function handler(href, options) {
                const { locale: nextLocale, ...rest } = options || {};
                syncLocaleCookie.default(localeCookie, pathname, locale, nextLocale);
                const args = [
                    localize(href, nextLocale)
                ];
                if (Object.keys(rest).length > 0) {
                    args.push(rest);
                }
                // @ts-expect-error -- This is ok
                return fn(...args);
            };
        }
        return {
            ...router,
            push: createHandler(router.push),
            replace: createHandler(router.replace),
            prefetch: createHandler(router.prefetch)
        };
    }, [
        locale,
        localeCookie,
        localePrefix,
        pathname,
        router
    ]);
}
exports.default = useBaseRouter;
}}),
"[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/react-client/createSharedPathnamesNavigation.js [app-ssr] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: require } = __turbopack_context__;
{
'use strict';
Object.defineProperty(exports, '__esModule', {
    value: true
});
var _rollupPluginBabelHelpers = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/_virtual/_rollupPluginBabelHelpers.js [app-ssr] (ecmascript)");
var React = __turbopack_require__("[project]/node_modules/.pnpm/next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-20241020__react@19.0.0-rc-65a56d0e-20241020/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var config = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/routing/config.js [app-ssr] (ecmascript)");
var ClientLink = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/react-client/ClientLink.js [app-ssr] (ecmascript)");
var redirects = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/react-client/redirects.js [app-ssr] (ecmascript)");
var useBasePathname = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/react-client/useBasePathname.js [app-ssr] (ecmascript)");
var useBaseRouter = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/react-client/useBaseRouter.js [app-ssr] (ecmascript)");
function _interopDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}
var React__default = /*#__PURE__*/ _interopDefault(React);
/**
 * @deprecated Consider switching to `createNavigation` (see https://next-intl-docs.vercel.app/blog/next-intl-3-22#create-navigation)
 **/ function createSharedPathnamesNavigation(routing) {
    const localePrefix = config.receiveLocalePrefixConfig(routing === null || routing === void 0 ? void 0 : routing.localePrefix);
    const localeCookie = config.receiveLocaleCookie(routing === null || routing === void 0 ? void 0 : routing.localeCookie);
    function Link(props, ref) {
        return /*#__PURE__*/ React__default.default.createElement(ClientLink.default, _rollupPluginBabelHelpers.extends({
            ref: ref,
            localeCookie: localeCookie,
            localePrefix: localePrefix
        }, props));
    }
    const LinkWithRef = /*#__PURE__*/ React.forwardRef(Link);
    LinkWithRef.displayName = 'Link';
    function redirect(pathname) {
        for(var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++){
            args[_key - 1] = arguments[_key];
        }
        return redirects.clientRedirect({
            pathname,
            localePrefix
        }, ...args);
    }
    function permanentRedirect(pathname) {
        for(var _len2 = arguments.length, args = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++){
            args[_key2 - 1] = arguments[_key2];
        }
        return redirects.clientPermanentRedirect({
            pathname,
            localePrefix
        }, ...args);
    }
    function usePathname() {
        const result = useBasePathname.default(localePrefix);
        // @ts-expect-error -- Mirror the behavior from Next.js, where `null` is returned when `usePathname` is used outside of Next, but the types indicate that a string is always returned.
        return result;
    }
    function useRouter() {
        return useBaseRouter.default(localePrefix, localeCookie);
    }
    return {
        Link: LinkWithRef,
        redirect,
        permanentRedirect,
        usePathname,
        useRouter
    };
}
exports.default = createSharedPathnamesNavigation;
}}),
"[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/react-client/createLocalizedPathnamesNavigation.js [app-ssr] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: require } = __turbopack_context__;
{
'use strict';
Object.defineProperty(exports, '__esModule', {
    value: true
});
var _rollupPluginBabelHelpers = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/_virtual/_rollupPluginBabelHelpers.js [app-ssr] (ecmascript)");
var React = __turbopack_require__("[project]/node_modules/.pnpm/next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-20241020__react@19.0.0-rc-65a56d0e-20241020/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var useLocale = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/react-client/useLocale.js [app-ssr] (ecmascript)");
var config = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/routing/config.js [app-ssr] (ecmascript)");
var utils = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/shared/utils.js [app-ssr] (ecmascript)");
var ClientLink = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/react-client/ClientLink.js [app-ssr] (ecmascript)");
var redirects = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/react-client/redirects.js [app-ssr] (ecmascript)");
var useBasePathname = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/react-client/useBasePathname.js [app-ssr] (ecmascript)");
var useBaseRouter = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/react-client/useBaseRouter.js [app-ssr] (ecmascript)");
function _interopDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}
var React__default = /*#__PURE__*/ _interopDefault(React);
/**
 * @deprecated Consider switching to `createNavigation` (see https://next-intl-docs.vercel.app/blog/next-intl-3-22#create-navigation)
 **/ function createLocalizedPathnamesNavigation(routing) {
    const config$1 = config.receiveRoutingConfig(routing);
    const localeCookie = config.receiveLocaleCookie(routing.localeCookie);
    function useTypedLocale() {
        const locale = useLocale.default();
        const isValid = config$1.locales.includes(locale);
        if (!isValid) {
            throw new Error("Unknown locale encountered: \"".concat(locale, "\". Make sure to validate the locale in `i18n.ts`."));
        }
        return locale;
    }
    function Link(_ref, ref) {
        let { href, locale, ...rest } = _ref;
        const defaultLocale = useTypedLocale();
        const finalLocale = locale || defaultLocale;
        return /*#__PURE__*/ React__default.default.createElement(ClientLink.default, _rollupPluginBabelHelpers.extends({
            ref: ref,
            href: utils.compileLocalizedPathname({
                locale: finalLocale,
                // @ts-expect-error -- This is ok
                pathname: href,
                // @ts-expect-error -- This is ok
                params: typeof href === 'object' ? href.params : undefined,
                pathnames: config$1.pathnames
            }),
            locale: locale,
            localeCookie: localeCookie,
            localePrefix: config$1.localePrefix
        }, rest));
    }
    const LinkWithRef = /*#__PURE__*/ React.forwardRef(Link);
    LinkWithRef.displayName = 'Link';
    function redirect(href) {
        // eslint-disable-next-line react-hooks/rules-of-hooks -- Reading from context here is fine, since `redirect` should be called during render
        const locale = useTypedLocale();
        const resolvedHref = getPathname({
            href,
            locale
        });
        for(var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++){
            args[_key - 1] = arguments[_key];
        }
        return redirects.clientRedirect({
            pathname: resolvedHref,
            localePrefix: config$1.localePrefix
        }, ...args);
    }
    function permanentRedirect(href) {
        // eslint-disable-next-line react-hooks/rules-of-hooks -- Reading from context here is fine, since `redirect` should be called during render
        const locale = useTypedLocale();
        const resolvedHref = getPathname({
            href,
            locale
        });
        for(var _len2 = arguments.length, args = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++){
            args[_key2 - 1] = arguments[_key2];
        }
        return redirects.clientPermanentRedirect({
            pathname: resolvedHref,
            localePrefix: config$1.localePrefix
        }, ...args);
    }
    function useRouter() {
        const baseRouter = useBaseRouter.default(config$1.localePrefix, localeCookie);
        const defaultLocale = useTypedLocale();
        return React.useMemo(()=>({
                ...baseRouter,
                push (href) {
                    var _args$;
                    for(var _len3 = arguments.length, args = new Array(_len3 > 1 ? _len3 - 1 : 0), _key3 = 1; _key3 < _len3; _key3++){
                        args[_key3 - 1] = arguments[_key3];
                    }
                    const resolvedHref = getPathname({
                        href,
                        locale: ((_args$ = args[0]) === null || _args$ === void 0 ? void 0 : _args$.locale) || defaultLocale
                    });
                    return baseRouter.push(resolvedHref, ...args);
                },
                replace (href) {
                    var _args$2;
                    for(var _len4 = arguments.length, args = new Array(_len4 > 1 ? _len4 - 1 : 0), _key4 = 1; _key4 < _len4; _key4++){
                        args[_key4 - 1] = arguments[_key4];
                    }
                    const resolvedHref = getPathname({
                        href,
                        locale: ((_args$2 = args[0]) === null || _args$2 === void 0 ? void 0 : _args$2.locale) || defaultLocale
                    });
                    return baseRouter.replace(resolvedHref, ...args);
                },
                prefetch (href) {
                    var _args$3;
                    for(var _len5 = arguments.length, args = new Array(_len5 > 1 ? _len5 - 1 : 0), _key5 = 1; _key5 < _len5; _key5++){
                        args[_key5 - 1] = arguments[_key5];
                    }
                    const resolvedHref = getPathname({
                        href,
                        locale: ((_args$3 = args[0]) === null || _args$3 === void 0 ? void 0 : _args$3.locale) || defaultLocale
                    });
                    return baseRouter.prefetch(resolvedHref, ...args);
                }
            }), [
            baseRouter,
            defaultLocale
        ]);
    }
    function usePathname() {
        const pathname = useBasePathname.default(config$1.localePrefix);
        const locale = useTypedLocale();
        // @ts-expect-error -- Mirror the behavior from Next.js, where `null` is returned when `usePathname` is used outside of Next, but the types indicate that a string is always returned.
        return React.useMemo(()=>pathname ? utils.getRoute(locale, pathname, config$1.pathnames) : pathname, [
            locale,
            pathname
        ]);
    }
    function getPathname(_ref2) {
        let { href, locale } = _ref2;
        return utils.compileLocalizedPathname({
            ...utils.normalizeNameOrNameWithParams(href),
            locale,
            pathnames: config$1.pathnames
        });
    }
    return {
        Link: LinkWithRef,
        redirect,
        permanentRedirect,
        usePathname,
        useRouter,
        getPathname
    };
}
exports.default = createLocalizedPathnamesNavigation;
}}),
"[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/shared/createSharedNavigationFns.js [app-ssr] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: require } = __turbopack_context__;
{
'use strict';
Object.defineProperty(exports, '__esModule', {
    value: true
});
var _rollupPluginBabelHelpers = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/_virtual/_rollupPluginBabelHelpers.js [app-ssr] (ecmascript)");
var navigation = __turbopack_require__("[project]/node_modules/.pnpm/next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-20241020__react@19.0.0-rc-65a56d0e-20241020/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var React = __turbopack_require__("[project]/node_modules/.pnpm/next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-20241020__react@19.0.0-rc-65a56d0e-20241020/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var config = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/routing/config.js [app-ssr] (ecmascript)");
var utils$1 = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/shared/utils.js [app-ssr] (ecmascript)");
var BaseLink = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/shared/BaseLink.js [app-ssr] (ecmascript)");
var utils = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/shared/utils.js [app-ssr] (ecmascript)");
function _interopDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}
var React__default = /*#__PURE__*/ _interopDefault(React);
/**
 * Shared implementations for `react-server` and `react-client`
 */ function createSharedNavigationFns(getLocale, routing) {
    const config$1 = config.receiveRoutingConfig(routing || {});
    {
        utils.validateReceivedConfig(config$1);
    }
    const pathnames = config$1.pathnames;
    // This combination requires that the current host is known in order to
    // compute a correct pathname. Since that can only be achieved by reading from
    // headers, this would break static rendering. Therefore, as a workaround we
    // always add a prefix in this case to be on the safe side. The downside is
    // that the user might get redirected again if the middleware detects that the
    // prefix is not needed.
    const forcePrefixSsr = config$1.localePrefix.mode === 'as-needed' && config$1.domains || undefined;
    function Link(_ref, ref) {
        let { href, locale, ...rest } = _ref;
        let pathname, params;
        if (typeof href === 'object') {
            pathname = href.pathname;
            // @ts-expect-error -- This is ok
            params = href.params;
        } else {
            pathname = href;
        }
        // @ts-expect-error -- This is ok
        const isLocalizable = utils$1.isLocalizableHref(href);
        const localePromiseOrValue = getLocale();
        const curLocale = localePromiseOrValue instanceof Promise ? React.use(localePromiseOrValue) : localePromiseOrValue;
        const finalPathname = isLocalizable ? getPathname(// @ts-expect-error -- This is ok
        {
            locale: locale || curLocale,
            href: pathnames == null ? pathname : {
                pathname,
                params
            }
        }, locale != null || forcePrefixSsr || undefined) : pathname;
        return /*#__PURE__*/ React__default.default.createElement(BaseLink.default, _rollupPluginBabelHelpers.extends({
            ref: ref,
            defaultLocale: config$1.defaultLocale,
            href: typeof href === 'object' ? {
                ...href,
                pathname: finalPathname
            } : finalPathname,
            locale: locale,
            localeCookie: config$1.localeCookie,
            unprefixed: forcePrefixSsr && isLocalizable ? {
                domains: config$1.domains.reduce((acc, domain)=>{
                    // @ts-expect-error -- This is ok
                    acc[domain.domain] = domain.defaultLocale;
                    return acc;
                }, {}),
                pathname: getPathname(// @ts-expect-error -- This is ok
                {
                    locale: curLocale,
                    href: pathnames == null ? pathname : {
                        pathname,
                        params
                    }
                }, false)
            } : undefined
        }, rest));
    }
    const LinkWithRef = /*#__PURE__*/ React.forwardRef(Link);
    function getPathname(args, /** @private Removed in types returned below */ _forcePrefix) {
        const { href, locale } = args;
        let pathname;
        if (pathnames == null) {
            if (typeof href === 'object') {
                pathname = href.pathname;
                if (href.query) {
                    pathname += utils.serializeSearchParams(href.query);
                }
            } else {
                pathname = href;
            }
        } else {
            pathname = utils.compileLocalizedPathname({
                locale,
                // @ts-expect-error -- This is ok
                ...utils.normalizeNameOrNameWithParams(href),
                // @ts-expect-error -- This is ok
                pathnames: config$1.pathnames
            });
        }
        return utils.applyPathnamePrefix(pathname, locale, config$1, // @ts-expect-error -- This is ok
        args.domain, _forcePrefix);
    }
    function getRedirectFn(fn) {
        /** @see https://next-intl-docs.vercel.app/docs/routing/navigation#redirect */ return function redirectFn(args) {
            for(var _len = arguments.length, rest = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++){
                rest[_key - 1] = arguments[_key];
            }
            return fn(// @ts-expect-error -- We're forcing the prefix when no domain is provided
            getPathname(args, args.domain ? undefined : forcePrefixSsr), ...rest);
        };
    }
    const redirect = getRedirectFn(navigation.redirect);
    const permanentRedirect = getRedirectFn(navigation.permanentRedirect);
    return {
        config: config$1,
        Link: LinkWithRef,
        redirect,
        permanentRedirect,
        // Remove `_forcePrefix` from public API
        getPathname: getPathname
    };
}
exports.default = createSharedNavigationFns;
}}),
"[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/react-client/createNavigation.js [app-ssr] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: require } = __turbopack_context__;
{
'use strict';
Object.defineProperty(exports, '__esModule', {
    value: true
});
var navigation = __turbopack_require__("[project]/node_modules/.pnpm/next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-20241020__react@19.0.0-rc-65a56d0e-20241020/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var React = __turbopack_require__("[project]/node_modules/.pnpm/next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-20241020__react@19.0.0-rc-65a56d0e-20241020/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var useLocale = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/react-client/useLocale.js [app-ssr] (ecmascript)");
var createSharedNavigationFns = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/shared/createSharedNavigationFns.js [app-ssr] (ecmascript)");
var syncLocaleCookie = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/shared/syncLocaleCookie.js [app-ssr] (ecmascript)");
var utils = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/shared/utils.js [app-ssr] (ecmascript)");
var useBasePathname = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/react-client/useBasePathname.js [app-ssr] (ecmascript)");
function createNavigation(routing) {
    function useTypedLocale() {
        return useLocale.default();
    }
    const { Link, config, getPathname, ...redirects } = createSharedNavigationFns.default(useTypedLocale, routing);
    /** @see https://next-intl-docs.vercel.app/docs/routing/navigation#usepathname */ function usePathname() {
        const pathname = useBasePathname.default(config.localePrefix);
        const locale = useTypedLocale();
        // @ts-expect-error -- Mirror the behavior from Next.js, where `null` is returned when `usePathname` is used outside of Next, but the types indicate that a string is always returned.
        return React.useMemo(()=>pathname && // @ts-expect-error -- This is fine
            config.pathnames ? utils.getRoute(locale, pathname, // @ts-expect-error -- This is fine
            config.pathnames) : pathname, [
            locale,
            pathname
        ]);
    }
    function useRouter() {
        const router = navigation.useRouter();
        const curLocale = useTypedLocale();
        const nextPathname = navigation.usePathname();
        return React.useMemo(()=>{
            function createHandler(fn) {
                return function handler(href, options) {
                    const { locale: nextLocale, ...rest } = options || {};
                    // @ts-expect-error -- We're passing a domain here just in case
                    const pathname = getPathname({
                        href,
                        locale: nextLocale || curLocale,
                        domain: window.location.host
                    });
                    const args = [
                        pathname
                    ];
                    if (Object.keys(rest).length > 0) {
                        // @ts-expect-error -- This is fine
                        args.push(rest);
                    }
                    fn(...args);
                    syncLocaleCookie.default(config.localeCookie, nextPathname, curLocale, nextLocale);
                };
            }
            return {
                ...router,
                /** @see https://next-intl-docs.vercel.app/docs/routing/navigation#userouter */ push: createHandler(router.push),
                /** @see https://next-intl-docs.vercel.app/docs/routing/navigation#userouter */ replace: createHandler(router.replace),
                /** @see https://next-intl-docs.vercel.app/docs/routing/navigation#userouter */ prefetch: createHandler(router.prefetch)
            };
        }, [
            curLocale,
            nextPathname,
            router
        ]);
    }
    return {
        ...redirects,
        Link,
        usePathname,
        useRouter,
        getPathname
    };
}
exports.default = createNavigation;
}}),
"[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation.react-client.js [app-ssr] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: require } = __turbopack_context__;
{
'use strict';
Object.defineProperty(exports, '__esModule', {
    value: true
});
var createSharedPathnamesNavigation = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/react-client/createSharedPathnamesNavigation.js [app-ssr] (ecmascript)");
var createLocalizedPathnamesNavigation = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/react-client/createLocalizedPathnamesNavigation.js [app-ssr] (ecmascript)");
var createNavigation = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation/react-client/createNavigation.js [app-ssr] (ecmascript)");
exports.createSharedPathnamesNavigation = createSharedPathnamesNavigation.default;
exports.createLocalizedPathnamesNavigation = createLocalizedPathnamesNavigation.default;
exports.createNavigation = createNavigation.default;
}}),
"[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/navigation.react-client.js [app-ssr] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: require } = __turbopack_context__;
{
'use strict';
if ("TURBOPACK compile-time falsy", 0) {
    "TURBOPACK unreachable";
} else {
    module.exports = __turbopack_require__("[project]/node_modules/.pnpm/next-intl@3.25.1_next@15.0.3_react-dom@19.0.0-rc-65a56d0e-20241020_react@19.0.0-rc-65a56d0e-2_femrh4wds34izboa6tviasui5q/node_modules/next-intl/dist/development/navigation.react-client.js [app-ssr] (ecmascript)");
}
}}),
"[project]/node_modules/.pnpm/lucide-react@0.462.0_react@19.0.0-rc-65a56d0e-20241020/node_modules/lucide-react/dist/esm/icons/undo.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: require } = __turbopack_context__;
{
/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_esm__({
    "default": (()=>Undo)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$462$2e$0_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/lucide-react@0.462.0_react@19.0.0-rc-65a56d0e-20241020/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-ssr] (ecmascript)");
;
const Undo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$462$2e$0_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])("Undo", [
    [
        "path",
        {
            d: "M3 7v6h6",
            key: "1v2h90"
        }
    ],
    [
        "path",
        {
            d: "M21 17a9 9 0 0 0-9-9 9 9 0 0 0-6 2.3L3 13",
            key: "1r6uu6"
        }
    ]
]);
;
 //# sourceMappingURL=undo.js.map
}}),
"[project]/node_modules/.pnpm/lucide-react@0.462.0_react@19.0.0-rc-65a56d0e-20241020/node_modules/lucide-react/dist/esm/icons/undo.js [app-ssr] (ecmascript) <export default as UndoIcon>": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, t: require } = __turbopack_context__;
{
__turbopack_esm__({
    "UndoIcon": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$462$2e$0_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$undo$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$462$2e$0_react$40$19$2e$0$2e$0$2d$rc$2d$65a56d0e$2d$20241020$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$undo$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/lucide-react@0.462.0_react@19.0.0-rc-65a56d0e-20241020/node_modules/lucide-react/dist/esm/icons/undo.js [app-ssr] (ecmascript)");
}}),

};

//# sourceMappingURL=%5Bproject%5D__10cda4._.js.map