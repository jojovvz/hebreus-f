"use strict";exports.id=2699,exports.ids=[2699],exports.modules={92699:(e,t,s)=>{s.r(t),s.d(t,{send:()=>i});var d=s(30651);let i=async({to:e,subject:t,text:s})=>{let i=`Sending email to ${e} with subject ${t}

`;i+=`Text: ${s}

`,d.v.log(i)}}};