export { githubRouteHandler as GET } from "auth/oauth/github";
