export { githubCallbackRouteHandler as GET } from "auth/oauth/github";
