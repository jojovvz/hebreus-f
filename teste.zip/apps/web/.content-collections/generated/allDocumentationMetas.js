export default [
  {
    "data": {
      "overview": "Übersicht"
    },
    "path": "",
    "locale": "de"
  },
  {
    "data": {
      "overview": "Overview"
    },
    "path": "",
    "locale": "en"
  },
  {
    "data": {
      "overview": "Overview",
      "macos": "macOS"
    },
    "path": "",
    "locale": "en"
  },
  {
    "data": {
      "getting-started": "Getting Started",
      "installation": "Installation"
    },
    "path": "",
    "locale": "en"
  }
];