export default [
  {
    "content": "Das hier ist die Übersichtseite.",
    "title": "Übersicht",
    "subtitle": "Das ist der erste Schritt",
    "_meta": {
      "filePath": "getting-started\\overview.de.md",
      "fileName": "overview.de.md",
      "directory": "getting-started",
      "extension": "md",
      "path": "getting-started\\overview.de"
    },
    "body": "var Component=(()=>{var d=Object.create;var r=Object.defineProperty;var p=Object.getOwnPropertyDescriptor;var _=Object.getOwnPropertyNames;var f=Object.getPrototypeOf,h=Object.prototype.hasOwnProperty;var j=(t,e)=>()=>(e||t((e={exports:{}}).exports,e),e.exports),l=(t,e)=>{for(var n in e)r(t,n,{get:e[n],enumerable:!0})},s=(t,e,n,i)=>{if(e&&typeof e==\"object\"||typeof e==\"function\")for(let o of _(e))!h.call(t,o)&&o!==n&&r(t,o,{get:()=>e[o],enumerable:!(i=p(e,o))||i.enumerable});return t};var D=(t,e,n)=>(n=t!=null?d(f(t)):{},s(e||!t||!t.__esModule?r(n,\"default\",{value:t,enumerable:!0}):n,t)),M=t=>s(r({},\"__esModule\",{value:!0}),t);var a=j((b,u)=>{u.exports=_jsx_runtime});var C={};l(C,{default:()=>x});var c=D(a());function m(t){let e={p:\"p\",...t.components};return(0,c.jsx)(e.p,{children:\"Das hier ist die \\xDCbersichtseite.\"})}function x(t={}){let{wrapper:e}=t.components||{};return e?(0,c.jsx)(e,{...t,children:(0,c.jsx)(m,{...t})}):m(t)}return M(C);})();\n;return Component;",
    "locale": "de",
    "path": "getting-started\\overview",
    "toc": []
  },
  {
    "content": "This is the overview page of the getting started section.\n\n![Login](/images/docs/login.png)",
    "title": "Overview",
    "subtitle": "This is the first step to start using acme",
    "_meta": {
      "filePath": "getting-started\\overview.md",
      "fileName": "overview.md",
      "directory": "getting-started",
      "extension": "md",
      "path": "getting-started\\overview"
    },
    "body": "var Component=(()=>{var d=Object.create;var s=Object.defineProperty;var p=Object.getOwnPropertyDescriptor;var x=Object.getOwnPropertyNames;var l=Object.getPrototypeOf,u=Object.prototype.hasOwnProperty;var _=(t,n)=>()=>(n||t((n={exports:{}}).exports,n),n.exports),f=(t,n)=>{for(var i in n)s(t,i,{get:n[i],enumerable:!0})},c=(t,n,i,r)=>{if(n&&typeof n==\"object\"||typeof n==\"function\")for(let o of x(n))!u.call(t,o)&&o!==i&&s(t,o,{get:()=>n[o],enumerable:!(r=p(n,o))||r.enumerable});return t};var j=(t,n,i)=>(i=t!=null?d(l(t)):{},c(n||!t||!t.__esModule?s(i,\"default\",{value:t,enumerable:!0}):i,t)),w=t=>c(s({},\"__esModule\",{value:!0}),t);var g=_((C,a)=>{a.exports=_jsx_runtime});var M={};f(M,{default:()=>h});var e=j(g());function m(t){let n={img:\"img\",p:\"p\",...t.components};return(0,e.jsxs)(e.Fragment,{children:[(0,e.jsx)(n.p,{children:\"This is the overview page of the getting started section.\"}),`\n`,(0,e.jsx)(n.p,{children:(0,e.jsx)(n.img,{src:\"/images/docs/login.png\",alt:\"Login\",width:\"2282\",height:\"1434\"})})]})}function h(t={}){let{wrapper:n}=t.components||{};return n?(0,e.jsx)(n,{...t,children:(0,e.jsx)(m,{...t})}):m(t)}return w(M);})();\n;return Component;",
    "locale": "en",
    "path": "getting-started\\overview",
    "toc": []
  },
  {
    "content": "Willkommen zur Dokumentation von acme. Hier finden Sie alle Informationen, die Sie benötigen, um mit unserer Software zu arbeiten.",
    "title": "Dokumentation",
    "_meta": {
      "filePath": "index.de.md",
      "fileName": "index.de.md",
      "directory": ".",
      "extension": "md",
      "path": "index.de"
    },
    "body": "var Component=(()=>{var l=Object.create;var r=Object.defineProperty;var d=Object.getOwnPropertyDescriptor;var x=Object.getOwnPropertyNames;var p=Object.getPrototypeOf,_=Object.prototype.hasOwnProperty;var j=(n,e)=>()=>(e||n((e={exports:{}}).exports,e),e.exports),D=(n,e)=>{for(var t in e)r(n,t,{get:e[t],enumerable:!0})},u=(n,e,t,m)=>{if(e&&typeof e==\"object\"||typeof e==\"function\")for(let o of x(e))!_.call(n,o)&&o!==t&&r(n,o,{get:()=>e[o],enumerable:!(m=d(e,o))||m.enumerable});return n};var M=(n,e,t)=>(t=n!=null?l(p(n)):{},u(e||!n||!n.__esModule?r(t,\"default\",{value:n,enumerable:!0}):t,n)),S=n=>u(r({},\"__esModule\",{value:!0}),n);var c=j((k,a)=>{a.exports=_jsx_runtime});var b={};D(b,{default:()=>f});var i=M(c());function s(n){let e={p:\"p\",...n.components};return(0,i.jsx)(e.p,{children:\"Willkommen zur Dokumentation von acme. Hier finden Sie alle Informationen, die Sie ben\\xF6tigen, um mit unserer Software zu arbeiten.\"})}function f(n={}){let{wrapper:e}=n.components||{};return e?(0,i.jsx)(e,{...n,children:(0,i.jsx)(s,{...n})}):s(n)}return S(b);})();\n;return Component;",
    "locale": "de",
    "path": "",
    "toc": []
  },
  {
    "content": "Welcome to the documentation of acme. Here you will find all the information you need to work with our software. \n\n\n## 1.1 Getting started - Overview\n\nLorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. \n\nDuis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. \n\n### Another sub-section\n\nLorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. \n\nDuis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. \n\n## Code example\n\nThis is an example of code highlighting:\n\n```python {1}\ndef hello_world():\n    print(\"Hello World!\")\n```\n\n## Images\n\nThis is an example of an image:\n\n![Login](/images/docs/login.png)\n\n## Lists\n\nThis is an example of a list:\n\n- Item 1\n- Item 2\n- Item 3",
    "title": "Documentation",
    "_meta": {
      "filePath": "index.md",
      "fileName": "index.md",
      "directory": ".",
      "extension": "md",
      "path": "index"
    },
    "body": "var Component=(()=>{var c=Object.create;var s=Object.defineProperty;var p=Object.getOwnPropertyDescriptor;var h=Object.getOwnPropertyNames;var g=Object.getPrototypeOf,v=Object.prototype.hasOwnProperty;var y=(i,e)=>()=>(e||i((e={exports:{}}).exports,e),e.exports),b=(i,e)=>{for(var o in e)s(i,o,{get:e[o],enumerable:!0})},r=(i,e,o,n)=>{if(e&&typeof e==\"object\"||typeof e==\"function\")for(let a of h(e))!v.call(i,a)&&a!==o&&s(i,a,{get:()=>e[a],enumerable:!(n=p(e,a))||n.enumerable});return i};var f=(i,e,o)=>(o=i!=null?c(g(i)):{},r(e||!i||!i.__esModule?s(o,\"default\",{value:i,enumerable:!0}):o,i)),L=i=>r(s({},\"__esModule\",{value:!0}),i);var d=y((C,l)=>{l.exports=_jsx_runtime});var k={};b(k,{default:()=>m});var t=f(d());function u(i){let e={code:\"code\",h2:\"h2\",h3:\"h3\",img:\"img\",li:\"li\",p:\"p\",pre:\"pre\",span:\"span\",ul:\"ul\",...i.components};return(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(e.p,{children:\"Welcome to the documentation of acme. Here you will find all the information you need to work with our software.\"}),`\n`,(0,t.jsx)(e.h2,{children:\"1.1 Getting started - Overview\"}),`\n`,(0,t.jsx)(e.p,{children:\"Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.\"}),`\n`,(0,t.jsx)(e.p,{children:\"Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.\"}),`\n`,(0,t.jsx)(e.h3,{children:\"Another sub-section\"}),`\n`,(0,t.jsx)(e.p,{children:\"Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.\"}),`\n`,(0,t.jsx)(e.p,{children:\"Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.\"}),`\n`,(0,t.jsx)(e.h2,{children:\"Code example\"}),`\n`,(0,t.jsx)(e.p,{children:\"This is an example of code highlighting:\"}),`\n`,(0,t.jsx)(e.pre,{className:\"shiki nord\",style:{backgroundColor:\"#2e3440ff\",color:\"#d8dee9ff\"},tabIndex:\"0\",children:(0,t.jsxs)(e.code,{children:[(0,t.jsxs)(e.span,{className:\"line\",children:[(0,t.jsx)(e.span,{style:{color:\"#81A1C1\"},children:\"def\"}),(0,t.jsx)(e.span,{style:{color:\"#88C0D0\"},children:\" hello_world\"}),(0,t.jsx)(e.span,{style:{color:\"#ECEFF4\"},children:\"():\"})]}),`\n`,(0,t.jsxs)(e.span,{className:\"line\",children:[(0,t.jsx)(e.span,{style:{color:\"#88C0D0\"},children:\"    print\"}),(0,t.jsx)(e.span,{style:{color:\"#ECEFF4\"},children:\"(\"}),(0,t.jsx)(e.span,{style:{color:\"#ECEFF4\"},children:'\"'}),(0,t.jsx)(e.span,{style:{color:\"#A3BE8C\"},children:\"Hello World!\"}),(0,t.jsx)(e.span,{style:{color:\"#ECEFF4\"},children:'\"'}),(0,t.jsx)(e.span,{style:{color:\"#ECEFF4\"},children:\")\"})]})]})}),`\n`,(0,t.jsx)(e.h2,{children:\"Images\"}),`\n`,(0,t.jsx)(e.p,{children:\"This is an example of an image:\"}),`\n`,(0,t.jsx)(e.p,{children:(0,t.jsx)(e.img,{src:\"/images/docs/login.png\",alt:\"Login\",width:\"2282\",height:\"1434\"})}),`\n`,(0,t.jsx)(e.h2,{children:\"Lists\"}),`\n`,(0,t.jsx)(e.p,{children:\"This is an example of a list:\"}),`\n`,(0,t.jsxs)(e.ul,{children:[`\n`,(0,t.jsx)(e.li,{children:\"Item 1\"}),`\n`,(0,t.jsx)(e.li,{children:\"Item 2\"}),`\n`,(0,t.jsx)(e.li,{children:\"Item 3\"}),`\n`]})]})}function m(i={}){let{wrapper:e}=i.components||{};return e?(0,t.jsx)(e,{...i,children:(0,t.jsx)(u,{...i})}):u(i)}return L(k);})();\n;return Component;",
    "locale": "en",
    "path": "",
    "toc": [
      {
        "content": "1.1 Getting started - Overview",
        "slug": "11-getting-started-overview",
        "lvl": 2,
        "i": 0,
        "seen": 0
      },
      {
        "content": "Another sub-section",
        "slug": "another-sub-section",
        "lvl": 3,
        "i": 1,
        "seen": 0
      },
      {
        "content": "Code example",
        "slug": "code-example",
        "lvl": 2,
        "i": 2,
        "seen": 0
      },
      {
        "content": "Images",
        "slug": "images",
        "lvl": 2,
        "i": 3,
        "seen": 0
      },
      {
        "content": "Lists",
        "slug": "lists",
        "lvl": 2,
        "i": 4,
        "seen": 0
      }
    ]
  },
  {
    "content": "asdf",
    "title": "Installation",
    "_meta": {
      "filePath": "installation\\index.md",
      "fileName": "index.md",
      "directory": "installation",
      "extension": "md",
      "path": "installation\\index"
    },
    "body": "var Component=(()=>{var d=Object.create;var r=Object.defineProperty;var f=Object.getOwnPropertyDescriptor;var p=Object.getOwnPropertyNames;var _=Object.getPrototypeOf,j=Object.prototype.hasOwnProperty;var l=(n,t)=>()=>(t||n((t={exports:{}}).exports,t),t.exports),M=(n,t)=>{for(var e in t)r(n,e,{get:t[e],enumerable:!0})},u=(n,t,e,s)=>{if(t&&typeof t==\"object\"||typeof t==\"function\")for(let o of p(t))!j.call(n,o)&&o!==e&&r(n,o,{get:()=>t[o],enumerable:!(s=f(t,o))||s.enumerable});return n};var h=(n,t,e)=>(e=n!=null?d(_(n)):{},u(t||!n||!n.__esModule?r(e,\"default\",{value:n,enumerable:!0}):e,n)),C=n=>u(r({},\"__esModule\",{value:!0}),n);var i=l((w,a)=>{a.exports=_jsx_runtime});var D={};M(D,{default:()=>x});var c=h(i());function m(n){let t={p:\"p\",...n.components};return(0,c.jsx)(t.p,{children:\"asdf\"})}function x(n={}){let{wrapper:t}=n.components||{};return t?(0,c.jsx)(t,{...n,children:(0,c.jsx)(m,{...n})}):m(n)}return C(D);})();\n;return Component;",
    "locale": "en",
    "path": "installation\\",
    "toc": []
  },
  {
    "content": "asdf",
    "title": "Installation on macos",
    "_meta": {
      "filePath": "installation\\macos.md",
      "fileName": "macos.md",
      "directory": "installation",
      "extension": "md",
      "path": "installation\\macos"
    },
    "body": "var Component=(()=>{var d=Object.create;var r=Object.defineProperty;var f=Object.getOwnPropertyDescriptor;var p=Object.getOwnPropertyNames;var _=Object.getPrototypeOf,j=Object.prototype.hasOwnProperty;var l=(n,t)=>()=>(t||n((t={exports:{}}).exports,t),t.exports),M=(n,t)=>{for(var e in t)r(n,e,{get:t[e],enumerable:!0})},u=(n,t,e,s)=>{if(t&&typeof t==\"object\"||typeof t==\"function\")for(let o of p(t))!j.call(n,o)&&o!==e&&r(n,o,{get:()=>t[o],enumerable:!(s=f(t,o))||s.enumerable});return n};var h=(n,t,e)=>(e=n!=null?d(_(n)):{},u(t||!n||!n.__esModule?r(e,\"default\",{value:n,enumerable:!0}):e,n)),C=n=>u(r({},\"__esModule\",{value:!0}),n);var i=l((w,a)=>{a.exports=_jsx_runtime});var D={};M(D,{default:()=>x});var c=h(i());function m(n){let t={p:\"p\",...n.components};return(0,c.jsx)(t.p,{children:\"asdf\"})}function x(n={}){let{wrapper:t}=n.components||{};return t?(0,c.jsx)(t,{...n,children:(0,c.jsx)(m,{...n})}):m(n)}return C(D);})();\n;return Component;",
    "locale": "en",
    "path": "installation\\macos",
    "toc": []
  },
  {
    "content": "This is the overview page of the getting started section.",
    "title": "Overview",
    "subtitle": "This is the first step to start using acme",
    "_meta": {
      "filePath": "installation\\overview.de.md",
      "fileName": "overview.de.md",
      "directory": "installation",
      "extension": "md",
      "path": "installation\\overview.de"
    },
    "body": "var Component=(()=>{var x=Object.create;var r=Object.defineProperty;var d=Object.getOwnPropertyDescriptor;var f=Object.getOwnPropertyNames;var h=Object.getPrototypeOf,_=Object.prototype.hasOwnProperty;var g=(t,e)=>()=>(e||t((e={exports:{}}).exports,e),e.exports),j=(t,e)=>{for(var n in e)r(t,n,{get:e[n],enumerable:!0})},s=(t,e,n,i)=>{if(e&&typeof e==\"object\"||typeof e==\"function\")for(let o of f(e))!_.call(t,o)&&o!==n&&r(t,o,{get:()=>e[o],enumerable:!(i=d(e,o))||i.enumerable});return t};var l=(t,e,n)=>(n=t!=null?x(h(t)):{},s(e||!t||!t.__esModule?r(n,\"default\",{value:t,enumerable:!0}):n,t)),M=t=>s(r({},\"__esModule\",{value:!0}),t);var u=g((C,a)=>{a.exports=_jsx_runtime});var v={};j(v,{default:()=>p});var c=l(u());function m(t){let e={p:\"p\",...t.components};return(0,c.jsx)(e.p,{children:\"This is the overview page of the getting started section.\"})}function p(t={}){let{wrapper:e}=t.components||{};return e?(0,c.jsx)(e,{...t,children:(0,c.jsx)(m,{...t})}):m(t)}return M(v);})();\n;return Component;",
    "locale": "de",
    "path": "installation\\overview",
    "toc": []
  },
  {
    "content": "This is the overview page of the getting started section.",
    "title": "Overview",
    "subtitle": "This is the first step to start using acme",
    "_meta": {
      "filePath": "installation\\overview.md",
      "fileName": "overview.md",
      "directory": "installation",
      "extension": "md",
      "path": "installation\\overview"
    },
    "body": "var Component=(()=>{var x=Object.create;var r=Object.defineProperty;var d=Object.getOwnPropertyDescriptor;var f=Object.getOwnPropertyNames;var h=Object.getPrototypeOf,_=Object.prototype.hasOwnProperty;var g=(t,e)=>()=>(e||t((e={exports:{}}).exports,e),e.exports),j=(t,e)=>{for(var n in e)r(t,n,{get:e[n],enumerable:!0})},s=(t,e,n,i)=>{if(e&&typeof e==\"object\"||typeof e==\"function\")for(let o of f(e))!_.call(t,o)&&o!==n&&r(t,o,{get:()=>e[o],enumerable:!(i=d(e,o))||i.enumerable});return t};var l=(t,e,n)=>(n=t!=null?x(h(t)):{},s(e||!t||!t.__esModule?r(n,\"default\",{value:t,enumerable:!0}):n,t)),M=t=>s(r({},\"__esModule\",{value:!0}),t);var u=g((C,a)=>{a.exports=_jsx_runtime});var v={};j(v,{default:()=>p});var c=l(u());function m(t){let e={p:\"p\",...t.components};return(0,c.jsx)(e.p,{children:\"This is the overview page of the getting started section.\"})}function p(t={}){let{wrapper:e}=t.components||{};return e?(0,c.jsx)(e,{...t,children:(0,c.jsx)(m,{...t})}):m(t)}return M(v);})();\n;return Component;",
    "locale": "en",
    "path": "installation\\overview",
    "toc": []
  }
];