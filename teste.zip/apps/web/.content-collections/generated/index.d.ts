import configuration from "../../content-collections.ts";
import { GetTypeByName } from "@content-collections/core";

export type Post = GetTypeByName<typeof configuration, "posts">;
export declare const allPosts: Array<Post>;

export type LegalPage = GetTypeByName<typeof configuration, "legalPages">;
export declare const allLegalPages: Array<LegalPage>;

export type DocumentationPage = GetTypeByName<typeof configuration, "documentationPages">;
export declare const allDocumentationPages: Array<DocumentationPage>;

export type DocumentationMeta = GetTypeByName<typeof configuration, "documentationMeta">;
export declare const allDocumentationMetas: Array<DocumentationMeta>;

export {};
