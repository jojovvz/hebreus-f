export default [
  {
    "content": "## Meine Lieblingsdinge\n\nDas ist ein Testpost. Hier schreibe ich über meine Lieblingsdinge.",
    "title": "Lieblingsdinge",
    "date": "2023-02-28",
    "image": "/images/blog/cover.png",
    "authorName": "Elon Musk",
    "authorImage": "/images/blog/author2.jpg",
    "excerpt": "Hier schreibe ich über meine Lieblingsdinge.",
    "tags": [
      "first",
      "post"
    ],
    "published": true,
    "_meta": {
      "filePath": "first-post.de.mdx",
      "fileName": "first-post.de.mdx",
      "directory": ".",
      "extension": "mdx",
      "path": "first-post.de"
    },
    "body": "var Component=(()=>{var x=Object.create;var r=Object.defineProperty;var l=Object.getOwnPropertyDescriptor;var u=Object.getOwnPropertyNames;var _=Object.getPrototypeOf,g=Object.prototype.hasOwnProperty;var p=(e,n)=>()=>(n||e((n={exports:{}}).exports,n),n.exports),j=(e,n)=>{for(var i in n)r(e,i,{get:n[i],enumerable:!0})},c=(e,n,i,o)=>{if(n&&typeof n==\"object\"||typeof n==\"function\")for(let s of u(n))!g.call(e,s)&&s!==i&&r(e,s,{get:()=>n[s],enumerable:!(o=l(n,s))||o.enumerable});return e};var b=(e,n,i)=>(i=e!=null?x(_(e)):{},c(n||!e||!e.__esModule?r(i,\"default\",{value:e,enumerable:!0}):i,e)),f=e=>c(r({},\"__esModule\",{value:!0}),e);var h=p((L,a)=>{a.exports=_jsx_runtime});var M={};j(M,{default:()=>d});var t=b(h());function m(e){let n={h2:\"h2\",p:\"p\",...e.components};return(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(n.h2,{children:\"Meine Lieblingsdinge\"}),`\n`,(0,t.jsx)(n.p,{children:\"Das ist ein Testpost. Hier schreibe ich \\xFCber meine Lieblingsdinge.\"})]})}function d(e={}){let{wrapper:n}=e.components||{};return n?(0,t.jsx)(n,{...e,children:(0,t.jsx)(m,{...e})}):m(e)}return f(M);})();\n;return Component;",
    "locale": "de",
    "path": "first-post"
  },
  {
    "content": "## This is a heading\n\nAnd we also have some great content here. What do you think?",
    "title": "Favorite Things",
    "date": "2023-02-28",
    "image": "/images/blog/cover.png",
    "authorName": "Elon Musk",
    "authorImage": "/images/blog/author2.jpg",
    "excerpt": "In this post I'm going to tell you about my favorite things.",
    "tags": [
      "first",
      "post"
    ],
    "published": true,
    "_meta": {
      "filePath": "first-post.mdx",
      "fileName": "first-post.mdx",
      "directory": ".",
      "extension": "mdx",
      "path": "first-post"
    },
    "body": "var Component=(()=>{var u=Object.create;var s=Object.defineProperty;var x=Object.getOwnPropertyDescriptor;var _=Object.getOwnPropertyNames;var l=Object.getPrototypeOf,j=Object.prototype.hasOwnProperty;var p=(n,e)=>()=>(e||n((e={exports:{}}).exports,e),e.exports),f=(n,e)=>{for(var o in e)s(n,o,{get:e[o],enumerable:!0})},c=(n,e,o,a)=>{if(e&&typeof e==\"object\"||typeof e==\"function\")for(let r of _(e))!j.call(n,r)&&r!==o&&s(n,r,{get:()=>e[r],enumerable:!(a=x(e,r))||a.enumerable});return n};var g=(n,e,o)=>(o=n!=null?u(l(n)):{},c(e||!n||!n.__esModule?s(o,\"default\",{value:n,enumerable:!0}):o,n)),M=n=>c(s({},\"__esModule\",{value:!0}),n);var i=p((C,h)=>{h.exports=_jsx_runtime});var w={};f(w,{default:()=>m});var t=g(i());function d(n){let e={h2:\"h2\",p:\"p\",...n.components};return(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(e.h2,{children:\"This is a heading\"}),`\n`,(0,t.jsx)(e.p,{children:\"And we also have some great content here. What do you think?\"})]})}function m(n={}){let{wrapper:e}=n.components||{};return e?(0,t.jsx)(e,{...n,children:(0,t.jsx)(d,{...n})}):d(n)}return M(w);})();\n;return Component;",
    "locale": "en",
    "path": "first-post"
  },
  {
    "content": "## Hello world\n\nThis is my first post. I'm so excited! This blog posts needs some more text lines to fill up the page, so I'm just going to write some random stuff here. I'm going to write about my favorite things, like:\n\n### What's next?\n\nI'm going to write a lot more posts. I'm going to write about my favorite things, like:\n\n- Cats\n- Dogs\n- Pizza\n\nYou can even add some nice links here:\n\n- [My favorite cat](https://www.youtube.com/watch?v=5dsGWM5XGdg)\n- [My favorite dog](https://www.youtube.com/watch?v=5dsGWM5XGdg)\n- [My favorite pizza](https://www.youtube.com/watch?v=5dsGWM5XGdg)\n- [Homepage](/)",
    "title": "Awesome second post",
    "date": "2023-03-01",
    "image": "/images/blog/cover.png",
    "authorName": "Tony Stark",
    "authorImage": "/images/blog/author.jpg",
    "excerpt": "This is my first post. I'm so excited!",
    "tags": [
      "first",
      "post"
    ],
    "published": true,
    "_meta": {
      "filePath": "second-post.mdx",
      "fileName": "second-post.mdx",
      "directory": ".",
      "extension": "mdx",
      "path": "second-post"
    },
    "body": "var Component=(()=>{var m=Object.create;var r=Object.defineProperty;var u=Object.getOwnPropertyDescriptor;var g=Object.getOwnPropertyNames;var w=Object.getPrototypeOf,f=Object.prototype.hasOwnProperty;var p=(t,e)=>()=>(e||t((e={exports:{}}).exports,e),e.exports),x=(t,e)=>{for(var i in e)r(t,i,{get:e[i],enumerable:!0})},h=(t,e,i,l)=>{if(e&&typeof e==\"object\"||typeof e==\"function\")for(let o of g(e))!f.call(t,o)&&o!==i&&r(t,o,{get:()=>e[o],enumerable:!(l=u(e,o))||l.enumerable});return t};var y=(t,e,i)=>(i=t!=null?m(w(t)):{},h(e||!t||!t.__esModule?r(i,\"default\",{value:t,enumerable:!0}):i,t)),v=t=>h(r({},\"__esModule\",{value:!0}),t);var c=p((b,s)=>{s.exports=_jsx_runtime});var M={};x(M,{default:()=>d});var n=y(c());function a(t){let e={a:\"a\",h2:\"h2\",h3:\"h3\",li:\"li\",p:\"p\",ul:\"ul\",...t.components};return(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(e.h2,{children:\"Hello world\"}),`\n`,(0,n.jsx)(e.p,{children:\"This is my first post. I'm so excited! This blog posts needs some more text lines to fill up the page, so I'm just going to write some random stuff here. I'm going to write about my favorite things, like:\"}),`\n`,(0,n.jsx)(e.h3,{children:\"What's next?\"}),`\n`,(0,n.jsx)(e.p,{children:\"I'm going to write a lot more posts. I'm going to write about my favorite things, like:\"}),`\n`,(0,n.jsxs)(e.ul,{children:[`\n`,(0,n.jsx)(e.li,{children:\"Cats\"}),`\n`,(0,n.jsx)(e.li,{children:\"Dogs\"}),`\n`,(0,n.jsx)(e.li,{children:\"Pizza\"}),`\n`]}),`\n`,(0,n.jsx)(e.p,{children:\"You can even add some nice links here:\"}),`\n`,(0,n.jsxs)(e.ul,{children:[`\n`,(0,n.jsx)(e.li,{children:(0,n.jsx)(e.a,{href:\"https://www.youtube.com/watch?v=5dsGWM5XGdg\",children:\"My favorite cat\"})}),`\n`,(0,n.jsx)(e.li,{children:(0,n.jsx)(e.a,{href:\"https://www.youtube.com/watch?v=5dsGWM5XGdg\",children:\"My favorite dog\"})}),`\n`,(0,n.jsx)(e.li,{children:(0,n.jsx)(e.a,{href:\"https://www.youtube.com/watch?v=5dsGWM5XGdg\",children:\"My favorite pizza\"})}),`\n`,(0,n.jsx)(e.li,{children:(0,n.jsx)(e.a,{href:\"/\",children:\"Homepage\"})}),`\n`]})]})}function d(t={}){let{wrapper:e}=t.components||{};return e?(0,n.jsx)(e,{...t,children:(0,n.jsx)(a,{...t})}):a(t)}return v(M);})();\n;return Component;",
    "locale": "en",
    "path": "second-post"
  }
];