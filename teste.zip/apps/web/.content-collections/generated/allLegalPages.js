export default [
  {
    "content": "Dies ist die Platzhalterseite für Ihre Datenschutzerklärung. Bearbeiten Sie die Datei `content/legal/privacy-policy.md`, um Ihren eigenen Inhalt hinzuzufügen.",
    "title": "Datenschutzerklärung",
    "_meta": {
      "filePath": "privacy-policy.de.md",
      "fileName": "privacy-policy.de.md",
      "directory": ".",
      "extension": "md",
      "path": "privacy-policy.de"
    },
    "body": "var Component=(()=>{var h=Object.create;var o=Object.defineProperty;var m=Object.getOwnPropertyDescriptor;var x=Object.getOwnPropertyNames;var p=Object.getPrototypeOf,f=Object.prototype.hasOwnProperty;var _=(e,n)=>()=>(n||e((n={exports:{}}).exports,n),n.exports),j=(e,n)=>{for(var t in n)o(e,t,{get:n[t],enumerable:!0})},s=(e,n,t,c)=>{if(n&&typeof n==\"object\"||typeof n==\"function\")for(let i of x(n))!f.call(e,i)&&i!==t&&o(e,i,{get:()=>n[i],enumerable:!(c=m(n,i))||c.enumerable});return e};var D=(e,n,t)=>(t=e!=null?h(p(e)):{},s(n||!e||!e.__esModule?o(t,\"default\",{value:e,enumerable:!0}):t,e)),g=e=>s(o({},\"__esModule\",{value:!0}),e);var u=_((I,a)=>{a.exports=_jsx_runtime});var z={};j(z,{default:()=>l});var r=D(u());function d(e){let n={code:\"code\",p:\"p\",...e.components};return(0,r.jsxs)(n.p,{children:[\"Dies ist die Platzhalterseite f\\xFCr Ihre Datenschutzerkl\\xE4rung. Bearbeiten Sie die Datei \",(0,r.jsx)(n.code,{children:\"content/legal/privacy-policy.md\"}),\", um Ihren eigenen Inhalt hinzuzuf\\xFCgen.\"]})}function l(e={}){let{wrapper:n}=e.components||{};return n?(0,r.jsx)(n,{...e,children:(0,r.jsx)(d,{...e})}):d(e)}return g(z);})();\n;return Component;",
    "locale": "de",
    "path": "privacy-policy"
  },
  {
    "content": "This is the placeholder page for your privacy policy. Edit the `content/legal/privacy-policy.md` file to add your own content here.",
    "title": "Privacy Policy",
    "_meta": {
      "filePath": "privacy-policy.md",
      "fileName": "privacy-policy.md",
      "directory": ".",
      "extension": "md",
      "path": "privacy-policy"
    },
    "body": "var Component=(()=>{var u=Object.create;var r=Object.defineProperty;var h=Object.getOwnPropertyDescriptor;var x=Object.getOwnPropertyNames;var m=Object.getPrototypeOf,y=Object.prototype.hasOwnProperty;var f=(e,t)=>()=>(t||e((t={exports:{}}).exports,t),t.exports),_=(e,t)=>{for(var n in t)r(e,n,{get:t[n],enumerable:!0})},s=(e,t,n,i)=>{if(t&&typeof t==\"object\"||typeof t==\"function\")for(let c of x(t))!y.call(e,c)&&c!==n&&r(e,c,{get:()=>t[c],enumerable:!(i=h(t,c))||i.enumerable});return e};var j=(e,t,n)=>(n=e!=null?u(m(e)):{},s(t||!e||!e.__esModule?r(n,\"default\",{value:e,enumerable:!0}):n,e)),M=e=>s(r({},\"__esModule\",{value:!0}),e);var a=f((w,d)=>{d.exports=_jsx_runtime});var g={};_(g,{default:()=>p});var o=j(a());function l(e){let t={code:\"code\",p:\"p\",...e.components};return(0,o.jsxs)(t.p,{children:[\"This is the placeholder page for your privacy policy. Edit the \",(0,o.jsx)(t.code,{children:\"content/legal/privacy-policy.md\"}),\" file to add your own content here.\"]})}function p(e={}){let{wrapper:t}=e.components||{};return t?(0,o.jsx)(t,{...e,children:(0,o.jsx)(l,{...e})}):l(e)}return M(g);})();\n;return Component;",
    "locale": "en",
    "path": "privacy-policy"
  },
  {
    "content": "Dies ist die Platzhalterseite für Ihre Allgemeinen Geschäftsbedingungen. Bearbeiten Sie die Datei `content/legal/terms.de.md`, um Ihren eigenen Inhalt hinzuzufügen.",
    "title": "Allgemeine Geschäftsbedingungen",
    "_meta": {
      "filePath": "terms.de.md",
      "fileName": "terms.de.md",
      "directory": ".",
      "extension": "md",
      "path": "terms.de"
    },
    "body": "var Component=(()=>{var m=Object.create;var r=Object.defineProperty;var h=Object.getOwnPropertyDescriptor;var x=Object.getOwnPropertyNames;var f=Object.getPrototypeOf,g=Object.prototype.hasOwnProperty;var _=(e,n)=>()=>(n||e((n={exports:{}}).exports,n),n.exports),j=(e,n)=>{for(var t in n)r(e,t,{get:n[t],enumerable:!0})},c=(e,n,t,s)=>{if(n&&typeof n==\"object\"||typeof n==\"function\")for(let o of x(n))!g.call(e,o)&&o!==t&&r(e,o,{get:()=>n[o],enumerable:!(s=h(n,o))||s.enumerable});return e};var p=(e,n,t)=>(t=e!=null?m(f(e)):{},c(n||!e||!e.__esModule?r(t,\"default\",{value:e,enumerable:!0}):t,e)),D=e=>c(r({},\"__esModule\",{value:!0}),e);var a=_((M,d)=>{d.exports=_jsx_runtime});var z={};j(z,{default:()=>u});var i=p(a());function l(e){let n={code:\"code\",p:\"p\",...e.components};return(0,i.jsxs)(n.p,{children:[\"Dies ist die Platzhalterseite f\\xFCr Ihre Allgemeinen Gesch\\xE4ftsbedingungen. Bearbeiten Sie die Datei \",(0,i.jsx)(n.code,{children:\"content/legal/terms.de.md\"}),\", um Ihren eigenen Inhalt hinzuzuf\\xFCgen.\"]})}function u(e={}){let{wrapper:n}=e.components||{};return n?(0,i.jsx)(n,{...e,children:(0,i.jsx)(l,{...e})}):l(e)}return D(z);})();\n;return Component;",
    "locale": "de",
    "path": "terms"
  },
  {
    "content": "This is the placeholder page for your terms and conditions. Edit the `content/legal/terms.md` file to add your own content here.",
    "title": "Terms and conditions",
    "_meta": {
      "filePath": "terms.md",
      "fileName": "terms.md",
      "directory": ".",
      "extension": "md",
      "path": "terms"
    },
    "body": "var Component=(()=>{var u=Object.create;var c=Object.defineProperty;var h=Object.getOwnPropertyDescriptor;var x=Object.getOwnPropertyNames;var p=Object.getPrototypeOf,f=Object.prototype.hasOwnProperty;var _=(e,t)=>()=>(t||e((t={exports:{}}).exports,t),t.exports),j=(e,t)=>{for(var n in t)c(e,n,{get:t[n],enumerable:!0})},d=(e,t,n,s)=>{if(t&&typeof t==\"object\"||typeof t==\"function\")for(let r of x(t))!f.call(e,r)&&r!==n&&c(e,r,{get:()=>t[r],enumerable:!(s=h(t,r))||s.enumerable});return e};var y=(e,t,n)=>(n=e!=null?u(p(e)):{},d(t||!e||!e.__esModule?c(n,\"default\",{value:e,enumerable:!0}):n,e)),M=e=>d(c({},\"__esModule\",{value:!0}),e);var a=_((C,i)=>{i.exports=_jsx_runtime});var g={};j(g,{default:()=>m});var o=y(a());function l(e){let t={code:\"code\",p:\"p\",...e.components};return(0,o.jsxs)(t.p,{children:[\"This is the placeholder page for your terms and conditions. Edit the \",(0,o.jsx)(t.code,{children:\"content/legal/terms.md\"}),\" file to add your own content here.\"]})}function m(e={}){let{wrapper:t}=e.components||{};return t?(0,o.jsx)(t,{...e,children:(0,o.jsx)(l,{...e})}):l(e)}return M(g);})();\n;return Component;",
    "locale": "en",
    "path": "terms"
  }
];