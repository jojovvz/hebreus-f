// content-collections.ts
import { defineCollection, defineConfig } from "@content-collections/core";
import { compileMDX } from "@content-collections/mdx";
import rehypeShiki from "@shikijs/rehype";
import markdownToc from "markdown-toc";
import rehypeImgSize from "rehype-img-size";
import { z } from "zod";

// ../../config.ts
var config = {
  i18n: {
    locales: {
      en: {
        currency: "USD",
        label: "English"
      },
      de: {
        currency: "USD",
        label: "Deutsch"
      }
    },
    defaultLocale: "en",
    defaultCurrency: "USD",
    localeCookieName: "NEXT_LOCALE"
  },
  teams: {
    avatarColors: ["#4e6df5", "#e5a158", "#9dbee5", "#ced3d9"]
  },
  auth: {
    redirectAfterLogout: "/",
    sessionCookieName: "auth_session",
    sessionCookieMaxAge: 60 * 60 * 24 * 30
  },
  mailing: {
    provider: "nodemailer",
    from: "contato@giovannimota.com.br"
  },
  ui: {
    enabledThemes: ["light", "dark"],
    defaultTheme: "light"
  }
};

// modules/shared/lib/content.ts
import slugify from "slugify";
function slugifyHeadline(headline) {
  return slugify(headline, {
    lower: true,
    replacement: "-",
    trim: true,
    strict: true,
    remove: /[*+~.()'"!:@]/g
  });
}

// content-collections.ts
function sanitizePath(path) {
  return path.replace(/(\.[a-zA-Z\\-]{2,5})$/, "").replace(/^\//, "").replace(/\/$/, "").replace(/index$/, "");
}
function getLocaleFromFilePath(path) {
  return path.match(/(\.[a-zA-Z\\-]{2,5})+\.(md|mdx|json)$/)?.[1]?.replace(".", "") ?? config.i18n.defaultLocale;
}
var posts = defineCollection({
  name: "posts",
  directory: "content/posts",
  include: "**/*.{mdx,md}",
  schema: (z2) => ({
    title: z2.string(),
    date: z2.string(),
    image: z2.string().optional(),
    authorName: z2.string(),
    authorImage: z2.string().optional(),
    authorLink: z2.string().optional(),
    excerpt: z2.string().optional(),
    tags: z2.array(z2.string()),
    published: z2.boolean()
  }),
  transform: async (document, context) => {
    const body = await compileMDX(context, document, {
      rehypePlugins: [
        [
          rehypeShiki,
          {
            theme: "nord"
          }
        ]
      ]
    });
    return {
      ...document,
      body,
      locale: getLocaleFromFilePath(document._meta.filePath),
      path: sanitizePath(document._meta.path)
    };
  }
});
var legalPages = defineCollection({
  name: "legalPages",
  directory: "content/legal",
  include: "**/*.{mdx,md}",
  schema: (z2) => ({
    title: z2.string()
  }),
  transform: async (document, context) => {
    const body = await compileMDX(context, document);
    return {
      ...document,
      body,
      locale: getLocaleFromFilePath(document._meta.filePath),
      path: sanitizePath(document._meta.path)
    };
  }
});
var documentationPages = defineCollection({
  name: "documentationPages",
  directory: "content/documentation",
  include: "**/*.{mdx,md}",
  schema: (z2) => ({
    title: z2.string(),
    subtitle: z2.string().optional()
  }),
  transform: async (document, context) => {
    const body = await compileMDX(context, document, {
      rehypePlugins: [
        [
          rehypeShiki,
          {
            theme: "nord"
          }
        ],
        [rehypeImgSize, { dir: "public" }]
      ]
    });
    const toc = markdownToc(document.content, { slugify: slugifyHeadline }).json;
    return {
      ...document,
      body,
      locale: getLocaleFromFilePath(document._meta.filePath),
      path: sanitizePath(document._meta.path),
      toc
    };
  }
});
var documentationMeta = defineCollection({
  name: "documentationMeta",
  directory: "content/documentation",
  include: "**/*.json",
  parser: "json",
  schema: () => ({
    items: z.record(
      z.union([
        z.string(),
        z.object({
          title: z.string()
        })
      ])
    )
  }),
  transform: async (document) => {
    return {
      data: document.items,
      path: document._meta.path.split("/").slice(0, -1).join("/"),
      locale: getLocaleFromFilePath(document._meta.filePath)
    };
  }
});
var content_collections_default = defineConfig({
  collections: [posts, legalPages, documentationPages, documentationMeta]
});
export {
  content_collections_default as default
};
